#if !defined(CRYTHE_H)


#include <stdio.h>
#include "types.h"
#include "ryinput.h"


// #define RY_TICK_LOOP

#if defined(RY_TICK_LOOP)
    #define RY_MSGQ_KEY_TYPE u32
#else
    #define RY_MSGQ_KEY_TYPE r32
#endif

#include "midimessage.h"

#define RY_MSGQ_SIZE                    1024
#define RY_MSGQ_MSG_TYPE                shortmsg
#include "msgq.h"


#define RY_MAX_DEV_NO                   16
#define RY_WRITEBUFFER_SIZE             (1 << 16)

#define RY_ON                           1
#define RY_OFF                          0
#define RY_BIT_READ(s, i)               ((s) >> (i) & 1)
#define RY_BIT_ON_AT(s, i)              ((RY_BIT_READ(s, i) & RY_ON))
#define RY_BIT_OFF_AT(s, i)             ((RY_BIT_READ(s, i) & RY_OFF) == 0)
                                        
#define RY_TICK_TYPE                    RY_MSGQ_KEY_TYPE

#define RY_BUFFER_TYPE                  i32
#define RY_BUFFER_HANDLE                RY_BUFFER_TYPE *
#define RY_CONST_BUFFER_HANDLE          RY_BUFFER_TYPE const *
#define RY_BUFFER_HANDLE_INVALID        nullptr
#define RY_BUFFER(name, ...)            static RY_BUFFER_TYPE name [] {__VA_ARGS__}
#define RY_BUFFER_SIZE(name)            (sizeof(name) / sizeof(RY_BUFFER_TYPE))
#define RY_CONST_BUFFER(name, ...)      static RY_BUFFER_TYPE const name [] {__VA_ARGS__}
#define RY_CONST_BUFFER_SIZE(name)      RY_BUFFER_SIZE(name)
#define RY_BUFFER_MAKE_WRITABLE(buffer) const_cast<RY_BUFFER_TYPE *>(buffer)

#define RY_DO_INIT                      init_state
#define RY_DO_UPDATE                    update_state
#define RY_DO_RENDER                    render_state
#define RY_DO_END                       end_state
#define CRYTHE_INIT(name)   			void name(ry_config *cfg, ry_state *state, ry_stream *stream, ry_buffer *wb)
#define CRYTHE_UPDATE(name) 			void name(RY_TICK_TYPE const tick)
#define CRYTHE_RENDER(name) 			void name(ry_backbuffer *buffer)
#define CRYTHE_END(name)    			void name(b32 const is_reload)
#define RY_STATE_INIT                   CRYTHE_INIT(RY_DO_INIT)
#define RY_STATE_UPDATE                 CRYTHE_UPDATE(RY_DO_UPDATE)
#define RY_STATE_RENDER                 CRYTHE_RENDER(RY_DO_RENDER)
#define RY_STATE_END                    CRYTHE_END(RY_DO_END)


struct ry_backbuffer {
    void *mem;
    int pitch, bpp;
    int width, height;
};

struct ry_config {
    i32 buffer_width, buffer_height;
    i32 screen_width, screen_height;
    b32 needs_focus;
    u32 num_devices;
    double sleep;
};

struct ry_stream {
    ry_msgq qsysex;
    ry_msgq qcontrols;
    ry_msgq qnotes;
};

struct ry_buffer {
    int size;
    int head;
    void *buffer;
};

struct ry_state {
    int key_press;
    i32 pointer_x, pointer_y;
    u16 pointer_state;
    i32 key_state[ry_key_count];
    const char *message;
};


void ry_halt(i32 const on_key);


#define CRYTHE_H
#endif
