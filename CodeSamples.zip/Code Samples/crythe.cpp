#include <stdlib.h>
#include "crythe.h"
#include "rycompile.h"
#define RY_INPUT_IMPLEMENTATION
#include "ryinput.h"
#define MIDIMESSAGE_IMPLEMENTATION
#include "midimessage.h"
#define RY_SYSEX_GENS_IMPLEMENTATION
#include "sysex.h"
#define MSGQ_IMPLEMENTATION
#include "msgq.h"
#define RY_GFX_RESPECT_BOUNDS
#define RY_GFX_IMPLEMENTATION
#include "ry_gfx.h"



#define ERR_TYPE        u32
#define BUFFER_WIDTH    128
#define BUFFER_HEIGHT   128
#define SCREEN_WIDTH    512
#define SCREEN_HEIGHT   512


static byte sysexbulk[32];
static u32 outs[RY_MAX_DEV_NO];
static ry_backbuffer backbuffer {};


//==============================================================================
void __ry_emptyfunc() {}

void __ry_itos(i32 v, char *bfr) {
    i32 n = 0;
    for (i32 m = v; m >= 10; m/=10, ++n);
    for (i32 i = 0, yk = 1; n >= 0; --n, ++i, yk = 1) {
        for (i32 _i = 0; _i < n; ++_i, yk*=10);
        i32 x = v / yk;
        bfr[i] = (char)('0' + x);
        v %= yk;
    }    
}

i32 __ry_halt_rel_key = 0;
void ry_halt(i32 const rel_key) {
    __ry_halt_rel_key = rel_key;
}
//==============================================================================
void      RyInitPlatform();
void      RyCleanupPlatform();
void      RySleep(unsigned const millisecs);
ry_time   RyNow();
ry_dur    RyTimeDiff(ry_time const t2, ry_time const t1);
void      *RyLoadLib(char const *path);
void      *RyGetLibFunc(void *lib, char const *proc_name);
void      RyFreeLib(void *lib);
b32       RyHandleUIMessages(ry_state *state); // return 0 if termination is requested
void      RyDraw();
b32       RyFileExists(char const *fname);
b32       RyFileNewer(char const *oldfname, char const *newfname);
b32       RyFileRemove(char const *path);
b32       RyFileCopy(char const *from, char const *to);
b32       RyIsSuccess(ERR_TYPE const err);
ERR_TYPE  RyMIDIOutDevOpen(u32 const handle, u32 const device_id);
ERR_TYPE  RyMIDIOutShortMsg(u32 const handle, shortmsg const msg);
ERR_TYPE  RyMIDIOutLongMsg(u32 const handle, longmsg const msg);
ERR_TYPE  RyMIDIOutDevReset(u32 const handle);
ERR_TYPE  RyMIDIOutDevClose(u32 const handle);
u32       RyMIDIOutDevsNo();
u32       RyAskMIDIOutDevs();
int       RyCreateWindow(i32 const width, i32 const height,
                         i32 const buffer_width, i32 const buffer_height,
                         b32 const needs_focus, ry_backbuffer *buffer);
void      RyDestroyWindow();
//==============================================================================

/*
static void  *ryballoc(ry_buffer * wb)
{
    if (wb->size >= RY_WRITEBUFFER_SIZE)
        return RY_BUFFER_HANDLE_INVALID;
    return wb->buffer + wb->size++;
}
*/

RY_STATE_INIT;
RY_STATE_UPDATE;
RY_STATE_RENDER;
RY_STATE_END;


#if defined(CRYTHE_LIVE)

#define RY_PROG_NAME		"rymodule.dll"
#define RY_PROG_INT_NAME	"rymodule.dll.loaded"
#define RY_PROG_LOAD_LOCK   "lock.txt"


#define CRYTHE_PROG_INIT(name) CRYTHE_INIT(name)
typedef CRYTHE_PROG_INIT(ry_prog_init);
CRYTHE_PROG_INIT(ry_prog_init_stub) {
    RY_CONSUME(cfg);
    RY_CONSUME(state);
    RY_CONSUME(stream);
    RY_CONSUME(wb);
}

#define CRYTHE_PROG_UPDATE(name) CRYTHE_UPDATE(name)
typedef CRYTHE_PROG_UPDATE(ry_prog_update);
CRYTHE_PROG_UPDATE(ry_prog_update_stub) {
}

#define CRYTHE_PROG_RENDER(name) CRYTHE_RENDER(name)
typedef CRYTHE_PROG_RENDER(ry_prog_render);
CRYTHE_PROG_RENDER(ry_prog_render_stub) {
    RY_CONSUME(buffer);
}

#define CRYTHE_PROG_END(name) CRYTHE_END(name)
typedef CRYTHE_PROG_END(ry_prog_end);
CRYTHE_PROG_END(ry_prog_end_stub) {
}

struct ry_prog {
    void *module;
    ry_prog_init   *init;
    ry_prog_update *update;
    ry_prog_render *render;
    ry_prog_end    *end;
} __g_prog;

RY_STATE_INIT   { __g_prog.init(cfg, state, stream, wb); }
RY_STATE_UPDATE { __g_prog.update(tick);    			 }
RY_STATE_RENDER { __g_prog.render(buffer);  			 }
RY_STATE_END    { __g_prog.end(is_reload);               }


static void RyLoadProg(char const *path, ry_prog *prog) {
    void* module = RyLoadLib(path);
    if (module) {
        prog->module  = module;
        prog->init    = (ry_prog_init   *)RyGetLibFunc(module, RY_STRINGIZE(RY_DO_INIT));
        prog->update  = (ry_prog_update *)RyGetLibFunc(module, RY_STRINGIZE(RY_DO_UPDATE));
        prog->render  = (ry_prog_render *)RyGetLibFunc(module, RY_STRINGIZE(RY_DO_RENDER));
        prog->end     = (ry_prog_end    *)RyGetLibFunc(module, RY_STRINGIZE(RY_DO_END));
    } else {
        prog->module  = nullptr;
        prog->init    = ry_prog_init_stub;
        prog->update  = ry_prog_update_stub;
        prog->render  = ry_prog_render_stub;
        prog->end     = ry_prog_end_stub;
    }
}

static b32 RyIsNewModuleAvailable(char const *ext_name, char const *int_name,
                                  char const *lock_name)
{
    if (ext_name && int_name) {
        if (RyFileExists(ext_name)
            && RyFileNewer(int_name, ext_name)
            && !RyFileExists(lock_name))
        {
            return 1;
        } else {
            return 0;
        }
    } else {
        return 0;
    }    
}

static b32 RyTryReloadProg(char const *ext_name, char const *int_name,
                           char const *lock_name,
                           ry_prog *prog)
{
    if (ext_name && int_name) {
        if (RyFileExists(ext_name)
            && RyFileNewer(int_name, ext_name)
            && !RyFileExists(lock_name))
        {
            if (prog->module) {
                RyFreeLib(prog->module);
            }
            prog->module = nullptr;
            RyFileRemove(int_name);
            RyFileCopy(ext_name, int_name);
            RyLoadProg(int_name, prog);
            return 1;
        } else {
            return 0;
        }
    } else {
        return 0;
    }
}

#else
    #include "tune.cpp"
#endif


static void DumpShortMsgQ(ry_msgq *q, key_type now, int device_id, int *counter) {
    if (*counter < q->count) { *counter = q->count; }
    while (q->count > 0 && (qpeek(q)->key <= now)) {
        auto e = qpop(q);
        RyMIDIOutShortMsg(device_id, e.msg);
    }
}


int main(int argc, char ** argv) {
    RY_CONSUME(argv);
    
    int retcode = 0;
    double const TickFreq = 10.0;

    ry_buffer wb {};
    ry_stream stream[RY_MAX_DEV_NO] {};
    ry_state state {};
    
    ry_config cfg {};
    cfg.buffer_width    = BUFFER_WIDTH;
    cfg.buffer_height   = BUFFER_HEIGHT;
    cfg.screen_width    = 0;
    cfg.screen_height   = 0;
    cfg.num_devices     = 1;
    cfg.sleep           = TickFreq;

    wb.head = 0;
    wb.size = 256 * 256 * 4;
    wb.buffer = malloc(wb.size);
    memset(wb.buffer, 0, wb.size);

    RyInitPlatform();

#if defined(CRYTHE_LIVE)
    if (!RyFileExists(RY_PROG_NAME)) {
        printf("[ERROR] no program module present to load!\n");
        return 11;
    }
    RyFileCopy(RY_PROG_NAME, RY_PROG_INT_NAME);
    RyLoadProg(RY_PROG_INT_NAME, &__g_prog);
#endif

    RY_DO_INIT(&cfg, &state, stream, &wb);
    
    i32 device_reqs[16];    
    if (RyMIDIOutDevsNo() == 1)
        device_reqs[0] = 0;
    else if (argc < 2) {
        for (u32 i = 0; i < cfg.num_devices; ++i)
            device_reqs[i] = RyAskMIDIOutDevs();
    }
    else {
        cfg.num_devices = argc - 1;
        for (i32 i = 1; i < argc; ++i)
            device_reqs[i - 1] = atoi(argv[i]);
    }

    u32 flag = 0, device_id = 0;    
    for (u32 i = 0; i < cfg.num_devices && RyIsSuccess(flag); ++i, device_id = i)
        flag = RyMIDIOutDevOpen(i, device_reqs[i]);


    void (*__rydraw)();
    bool drawing = cfg.screen_width && cfg.screen_height;
    if (drawing) {
        retcode = RyCreateWindow(cfg.screen_width, cfg.screen_height,
                                cfg.buffer_width, cfg.buffer_height,
                                cfg.needs_focus,
                                &backbuffer);
        __rydraw = RyDraw;
    } else {
        __rydraw = __ry_emptyfunc;
    }

    if (RyIsSuccess(retcode) && RyIsSuccess(flag)) {
        u32 current_tick = 0;        
        i32 qcontrols_max_size = 0, qnotes_max_size = 0;
        b32 running = 1, mute = 0;
        
        ry_time tstart = RyNow();
        ry_time tlast = tstart;

        while (running) {
            if (_kbhit()) {
                state.key_press = _getch();
            }

            if (!RyHandleUIMessages(&state)) {
                running = 0;
            }

            ry_time now    = RyNow();
            ry_dur elapsed = RyTimeDiff(now, tlast);

            {
#if defined(CRYTHE_LIVE)
                if (RyIsNewModuleAvailable(RY_PROG_NAME, RY_PROG_INT_NAME, RY_PROG_LOAD_LOCK)) {
                    RY_DO_END(1);

                    if (RyTryReloadProg(RY_PROG_NAME, RY_PROG_INT_NAME, RY_PROG_LOAD_LOCK, &__g_prog)) {
                        ///TODO: reconfig Window & UI in general?
                        RY_DO_INIT(&cfg, &state, stream, &wb);
                        printf("[INFO] loaded new module successfully!\n");
                    }                    
                }
#endif
                key_type tick =
#if defined(RY_TICK_LOOP)
                    current_tick
#else
                    (r32)RyTimeDiff(now, tstart)
#endif
                    ;

                // if (__ry_halt_rel_key) {
                //     if (ry_key_up(&state, __ry_halt_rel_key)) {
                //         __ry_halt_rel_key = 0;
                //     }
                // } else {
                RY_DO_UPDATE(tick);
                // }
                RY_DO_RENDER(&backbuffer);

                for (u32 z = 0; z < cfg.num_devices; ++z) {
                    // SYSEX
                    for (auto *q = &stream[z].qsysex;
                         q->count > 0 && (qpeek(q)->key <= tick);)
                    {
                        auto e = qpop(q);
                        longmsg long_msg {};
                        long_msg.len = expand_word_2_sysex(e.msg.word, sysexbulk);
                        long_msg.data = (byte *)sysexbulk;
                        RyMIDIOutLongMsg(z, long_msg);
                    }

                    // CC & PC
                    DumpShortMsgQ(&stream[z].qcontrols , tick, z, &qcontrols_max_size);

                    // Note Data
                    DumpShortMsgQ(&stream[z].qnotes    , tick, z, &qnotes_max_size);
                }

                // r32 avg_fps = current_tick / (tick / 1000.0f);
                // i32 fps_int = avg_fps > 999.0 ? 999 : (i32)avg_fps;
                // char fps_bfr[3] = {};
                // rygfx_canvas_t canvas = { cfg.buffer_width, cfg.buffer_height, (i32 *)backbuffer.mem};
                // __ry_itos(fps_int, fps_bfr);
                // rygfx_set_stroke(255, 255, 255);
                // rygfx_text(&canvas, fps_bfr, 1, 5, 5);

                /*
                if (drawing) {
                    draw();
                    }*/
                __rydraw();

                ++current_tick;
                tlast = now;    

                // TODO: Why reset here?
                state.pointer_state = 0;
            }

            // Quit by Q?
            if        (state.key_press == 'Q' || state.key_press == 'q') {
                running = 0;
            } else if (state.key_press == 'M' || state.key_press == 'm') {
                mute = !mute;
                printf("%s!\n", mute ? "mute" : "unmute");
            } else if (state.key_press == 'F' || state.key_press == 'f') {
                elapsed = cfg.sleep;
            }
            state.key_press = 0;

            // Quit by ESC?
            if (state.key_state[ry_key_escape] == ry_key_state_up)
                running = 0;
            for (int i = 0; i < ry_key_count; ++i) {
                if (state.key_state[i] == ry_key_state_up)
                    state.key_state[i] = ry_key_state_none;
            }

            // RySleep(1);
        }

        RY_DO_END(0);

        for (u32 i = 0; i < cfg.num_devices; ++i) {
            RyMIDIOutDevReset(i);
            RyMIDIOutDevClose(i);
        }

        RyCleanupPlatform();
        
        printf("execution complete!\n");
        printf("[INFO] write-buffer allocations: %d\n", wb.head);
        printf("[INFO] max number of control messages queued: %d\n", qcontrols_max_size);
        printf("[INFO] max number of note messages queued: %d\n", qnotes_max_size);

        retcode = 0;
    } else {
        printf("[ERROR] failed to initialize device %d!\n", device_id);
        retcode = 1;        
    }
    
    return retcode;
}
