using System.Collections.Generic;

namespace Tor.Benzaiten
{
    using Util;

    using i32 = System.Int32;
    using u32 = System.UInt32;
    using f32 = System.Single;
    using str = System.String;


    public class Memory
    {
        public class StrRefEqualityComparer : IEqualityComparer<string>
        {
            public bool Equals(string a, string b) {
                // return a.Equals(b);
                return a == b;
            }
            public int GetHashCode(string s) {
                return s.GetHashCode();
            }
        }

        public Memory parent;
        public FixedArray<i32> const_i32;
        public FixedArray<f32> const_f32;
        public FixedArray<str> const_str;
        public FixedArray<i32>   var_i32;
        public FixedArray<f32>   var_f32;
        public FixedArray<str>   var_str;
        public FixedStack<i32> stack_i32;
        public FixedStack<f32> stack_f32;
        public FixedStack<str> stack_str;
        public FixedArray<str>       rts;
        public Dictionary<str, i32> symtab;// {get; private set;}


        public Memory(int size) : this(size, size, size, size, size, size, size, size, size, size) {}
        public Memory() : this(Benzaiten.Size_Def_Memory) {}
        public Memory(int const_i32_size, int const_f32_size, int const_str_size,
                      int var_i32_size  , int var_f32_size  , int var_str_size,
                      int stack_i32_size, int stack_f32_size, int stack_str_size,
                      int rts_heap_size)
        {
            const_i32 = new FixedArray<i32>(const_i32_size, Predicates.Predicate_I32);
            const_f32 = new FixedArray<f32>(const_f32_size, Predicates.Predicate_F32);
            const_str = new FixedArray<str>(const_str_size, Predicates.Predicate_Str);
            stack_i32 = new FixedStack<i32>(stack_i32_size);
            stack_f32 = new FixedStack<f32>(stack_f32_size);
            stack_str = new FixedStack<str>(stack_str_size);
            var_i32   = new FixedArray<i32>(var_i32_size);
            var_f32   = new FixedArray<f32>(var_f32_size);
            var_str   = new FixedArray<str>(var_str_size);
            rts       = new FixedArray<str>(rts_heap_size);
            symtab    = new Dictionary<string, int>(var_i32_size + var_f32_size + var_str_size,
                                                    new StrRefEqualityComparer());
                                                    // System.StringComparer.InvariantCulture);
        }

        public void Clear()
        {
            for (int i = 0; i < rts.count; ++i)
                symtab[rts[i]] = (Compiler.Cat_Var << Benzaiten.Shift_Cat) | (Compiler.Type_Runtime << Benzaiten.Shift_Typ) | (i & Benzaiten.Mask_VarAddr);

            for (int i = 0; i < var_i32.count; ++i) {
                var_i32[i] = 0;
            }
            var_i32.Clear();

            for (int i = 0; i < var_f32.count; ++i) {
                var_f32[i] = 0;
            }
            var_f32.Clear();

            for (int i = 0; i < var_str.count; ++i) {
                var_str[i] = null;
            }
            var_str.Clear();

            Benzaiten.DeclareCommonSysVars(this);
        }

        private i32 __Addr(string name) {

            name = Str.Intern(name);
            return symtab[name] & Benzaiten.Mask_VarAddr;
        }

        private int __Decl(string name, int type, int __index) {
            name = Str.Intern(name);
            int vard = (Compiler.Cat_Var << Benzaiten.Shift_Cat) |
                       (type << Benzaiten.Shift_Typ) |
                       (__index & Benzaiten.Mask_VarAddr);
            symtab[name] = vard;
            return vard;
        }

        public int DeclareConstI32(i32 v, bool ignore_duplicate = false) {
            int index;
            if (ignore_duplicate) {
                index = const_i32.PushAndTell(v);
            } else {
                index = const_i32.FirstIndex(v);
                if (index < 0) {
                    index = const_i32.PushAndTell(v);
                }
            }
            return index;
        }

        public int DeclareConstF32(f32 v, bool ignore_duplicate = false) {
            int index;
            if (ignore_duplicate) {
                index = const_f32.PushAndTell(v);
            } else {
                index = const_f32.FirstIndex(v);
                if (index < 0) {
                    index = const_f32.PushAndTell(v);
                }
            }
            return index;
        }

        public int DeclareConstStr(str v, bool ignore_duplicate = false)
        {
            int index;
            if (ignore_duplicate) {
                index = const_str.PushAndTell(v);
            } else {
                index = const_str.FirstIndex(v);
                if (index < 0) {
                    index = const_str.PushAndTell(v);
                }
            }
            return index;
        }

        public i32 GetConstI32(int t) {return const_i32[t & Benzaiten.Mask_VarAddr];}
        public f32 GetConstF32(int t) {return const_f32[t & Benzaiten.Mask_VarAddr];}
        public str GetConstStr(int t) {return const_str[t & Benzaiten.Mask_VarAddr];}

        public int GetAddr(string name) 
        {
            name = Str.Intern(name);
            Assert.Do(symtab.TryGetValue(name, out int ret), "-- symbol \"{0}\" not declared...", name);
            return ret;
        }
        public int GetAddrSafe(string name) 
        {
            if (!symtab.TryGetValue(name, out int ret)) {
                ret = -1;
            }
            return ret;
        }
        
        public int Declare(string name) 
        {
            return __Decl(name, Compiler.Type_Runtime, rts.PushAndTell(name));
        }

        public void DeclareI32(string name, i32 val = 0)    {__Decl(name, Compiler.Type_I32, var_i32.PushAndTell(val));}
        public void DeclareF32(string name, f32 val = 0f)   {__Decl(name, Compiler.Type_F32, var_f32.PushAndTell(val));}
        public void DeclareStr(string name, str val = null) {__Decl(name, Compiler.Type_Str, var_str.PushAndTell(val));}
        public void SetI32(string name, int val) {var_i32[__Addr(name)] = val;}
        public void SetF32(string name, f32 val) {var_f32[__Addr(name)] = val;}
        public void SetStr(string name, str val) {var_str[__Addr(name)] = val;}
        public void SetI32(int t, int val) {var_i32[t & Benzaiten.Mask_VarAddr] = val;}
        public void SetF32(int t, f32 val) {var_f32[t & Benzaiten.Mask_VarAddr] = val;}
        public void SetStr(int t, str val) {var_str[t & Benzaiten.Mask_VarAddr] = val;}
        public i32 GetI32(int t) {return var_i32[t & Benzaiten.Mask_VarAddr];}
        public f32 GetF32(int t) {return var_f32[t & Benzaiten.Mask_VarAddr];}
        public str GetStr(int t) {return var_str[t & Benzaiten.Mask_VarAddr];}        

        public void Push(i32 v) {stack_i32.Push(v);}
        public void Push(f32 v) {stack_f32.Push(v);}
        public void Push(str v) {stack_str.Push(v);}
        public i32 PopI32() {return stack_i32.Pop();}
        public f32 PopF32() {return stack_f32.Pop();}
        public str PopStr() {return stack_str.Pop();}
    }
}
