﻿namespace Tor.Math
{
    public class GaussianEliminator
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="eqs">The equations. If there are N equations in
        ///  the rows of the matrix, each of them must have N+1 components.</param>
        /// <returns></returns>
        static public double[] Solve(double[,] eqs)
        {
            int R = Rows(eqs);
            int C = Cols(eqs);

            if (R < 1 || R + 1 != C)
                return null;    // No equations or not the correct shape...

            for (int i = 0; i < R; ++i)
            {
                if (!PutNonzeroElementAt(eqs, i, i))
                    return null;    // All zeros in the column i; means that
                                    //the equations were not all independent
                                    //(not necessarily the one at row i.)
                for (int j = 0; j < R; ++j)
                    if (j != i)
                        ReduceRow(eqs, j, i, i);
            }

            /* The matrix is now in the form:
             *    x 0 0 0 a
             *    0 y 0 0 b
             *    0 0 z 0 c
             *    0 0 0 w d
             * which means that the answers are:
             *    a/x, b/y, c/z. d/w
             */

            var ret = new double[R];
            for (int i = 0; i < R; ++i)
                ret[i] = eqs[i, C - 1] / eqs[i, i];
            return ret;
        }

        static private int Rows(double[,] eqs) { return eqs.GetLength(0); }
        static private int Cols(double[,] eqs) { return eqs.GetLength(1); }

        static private void SwapRows(double[,] eqs, int r1, int r2)
        {
            for (int i = 0, n = Cols(eqs); i < n; ++i)
            {
                var t = eqs[r1, i];
                eqs[r1, i] = eqs[r2, i];
                eqs[r2, i] = t;
            }
        }

        static private void MulAddRows(double[,] eqs, int row_to_be_modified, int row_to_be_used, double coef)
        {
            for (int i = 0, n = Cols(eqs); i < n; ++i)
                eqs[row_to_be_modified, i] += coef * eqs[row_to_be_used, i];
        }

        static private bool ReduceRow(double[,] eqs, int target_row, int using_row, int using_col)
        {
            if (IsZero(eqs[using_row, using_col]))
                return false;   // The way I've used this function, this never happens.
            if (IsZero(eqs[target_row, using_col]))
                return true;

            MulAddRows(eqs, target_row, using_row, -eqs[target_row, using_col] / eqs[using_row, using_col]);

            return IsZero(eqs[target_row, using_col]);  // The way I've used this function, this is always true.
        }

        static private bool PutNonzeroElementAt(double[,] eqs, int r, int c)
        {
            if (!IsZero(eqs[r, c]))
                return true;    // Yay!

            for (int i = r + 1, n = Rows(eqs); i < n; ++i)
                if (!IsZero(eqs[i, c]))
                {
                    SwapRows(eqs, r, i);
                    return true;
                }

            return false;
        }

        static private bool IsZero(double x)
        {
            const double epsilon = 1e-7;
            return x < epsilon && x > -epsilon;
        }
    }
}
