﻿// #define DEBUG_LOG_TRAVERSE_TIME


using System.Collections.Generic;
using System.Text;


namespace Tor.Benzaiten
{
    using Kami;
    using Util;

    using i32 = System.Int32;
    using u32 = System.UInt32;
    using f32 = System.Single;
    using str = System.String;
    using NodeArray = Util.FixedArray<System.Int32>;


    public class QueryResult : FixedArray<int> 
    {
        public QueryResult(int capacity) : base(capacity) {}
    }

    public class Forest : List<i32> {
        //TODO(psj): this container has a fixed size, find it.
        public List <i32> lids;

        public Forest() : this(Benzaiten.Cap_Def_Forest) {}
        public Forest(int capacity)
        : base(capacity) {
            lids = new List<i32>(capacity);
        }
    }

    public struct Event {
        public int index;
        public bool empty {get {return index == 0;}}

        Event(int index) {
            this.index = index;
        }

        public static Event NewEvent(int index) {
            return new Event(index);
        }

        public static Event NewEventSingle(int event_id) {
            return new Event(Compiler.FindOrCreateEventsIndex((ulong)(1 << event_id)));
        }
    }

    public struct Action {
        public int text;
        public int ryo;
        public int food;
        public int shame_ninjo;
        public int shame_giri;
        public int energy;
        public int mushin;
        public int morale;
        public int fame;
        public int courage_fame;
        public int comradery;
        public int wounds;

        public int morale_positive;
        public int morale_negative;

        public Event events;
        public int on_select;
        public NodeArray next;
    }


    public struct Context {
        public Entity self,other;
        public Context [] parent;

        public Context(Entity self, Entity other, Context [] parents) {
            this.self = self;
            this.other = other;
            this.parent = parents;
        }
        
        public Context(Entity self)
        : this(self, null, null) {
        }

        public Context(Entity self, Entity other)
        : this(self, other, null) {
        }

        public Context(Entity self, Entity other, Context parent)
        : this(self, other, new Context[]{parent}) {
        }

    }
    

    public class StreamBuffer
    {
        public Event            events;
        public string           actor;
        public bool []          condres;
        public FixedArray<int>  next;
        public FixedArray<int>  mute;

        public StreamBuffer() {
        }
    }


    public static partial class Benzaiten
    {
        public enum VALUE {PENDING, RUNNING, SUCCESS, FAILURE}

        public struct TraverseState
        {
            public int index;
            public VALUE val;
            public TraverseState(int index, VALUE res)
            {
                this.index = index;
                this.val = res;
            }
            public TraverseState(TraverseState state, VALUE res)
            {
                this.index = state.index;
                this.val   = res;
            }
            public override string ToString()
            {
                return string.Format("{0} -- {1}", index, val);
            }
        }


        public struct ParamString {
            public readonly Localization.LocData loc_data;
            // public readonly FixedArray<string> param_arr;
            // NOTE(psj): The param_dic container can be created once for each string
            // instance. Keys never change, but values do (i.e. values need to be stored
            // in a unique-to-instance container.
            // TODO(psj): While lexing cards, construct dictionary, remember length.
            public readonly System.Collections.Generic.Dictionary<string, string> param_dic;

            public bool valid {get {return loc_data.str_key != null;} }
            public bool parameterized { get {return null != param_dic;} }

            public ParamString(string key_str,
                               int file_id, int line_id, int node_id,
                               int param_count)
            {
                loc_data = new Localization.LocData(key_str, file_id, line_id, node_id);
                param_dic = param_count > 0 ? new System.Collections.Generic.Dictionary<string, string>() : null;
            }
        }


        //TODO(psj): move defs
        public static readonly string SS_PlayerName  = Str.Intern("PLAYER_NAME");
        public static readonly string SS_SelfName    = Str.Intern("SELF_NAME");
        public static readonly string SS_OtherName   = Str.Intern("OTHER_NAME");
        // public const string SS_GroupName = "GROUP_NAME";
        public static readonly string SS_Location = Str.Intern("LOCATION");

        public static readonly string SysVar_Ryo          = Str.Intern("Ryo");
        public static readonly string SysVar_Food         = Str.Intern("Food");
        public static readonly string SysVar_Fame         = Str.Intern("Fame");
        public static readonly string SysVar_SwordFame    = Str.Intern("SwordFame");
        public static readonly string SysVar_Mind         = Str.Intern("Mind");
        public static readonly string SysVar_Spirit       = Str.Intern("Spirit");
        public static readonly string SysVar_Energy       = Str.Intern("Energy");
        public static readonly string SysVar_Shame        = Str.Intern("Shame");
        public static readonly string SysVar_Starvation   = Str.Intern("Starvation");
        public static readonly string SysVar_Wounds       = Str.Intern("Wounds");
        public static readonly string SysVar_Comradery    = Str.Intern("Comradery");
        public static readonly string SysVar_Drunkenness  = Str.Intern("Drunkenness");
        public static readonly string SysVar_Mood         = Str.Intern("Mood");
        public static readonly string SysVar_Region       = Str.Intern("Region");
        public static readonly string SysVar_Location     = Str.Intern("Location");
        public static readonly string SysVar_LocationType = Str.Intern("LocationType");
        public static readonly string SysVar_HeadCount    = Str.Intern("HeadCount");
        public static readonly string SysVar_Hour         = Str.Intern("Hour");
        public static readonly string SysVar_Upbeat       = Str.Intern("Upbeat");
        public static readonly string SysVar_Joyful       = Str.Intern("Joyful");
        public static readonly string SysVar_Pleased      = Str.Intern("Pleased");
        public static readonly string SysVar_Mellow       = Str.Intern("Mellow");
        public static readonly string SysVar_Depressed    = Str.Intern("Depressed");
        public static readonly string SysVar_Disgusted    = Str.Intern("Disgusted");
        public static readonly string SysVar_Angry        = Str.Intern("Angry");
        public static readonly string SysVar_Stressed     = Str.Intern("Stressed");
        public static readonly string SysVar_Emotion      = Str.Intern("Emotion");


        public static void DeclareCommonSysVars(Tor.Benzaiten.Memory mem)
        {
            mem.DeclareStr(SysVar_Mood);
            mem.DeclareStr(SysVar_Region);
            mem.DeclareStr(SysVar_Location);
            mem.DeclareStr(SysVar_LocationType);
            mem.DeclareI32(SysVar_HeadCount);
            mem.DeclareI32(SysVar_Hour);

            mem.DeclareF32(SysVar_Comradery);
            // mem.DeclareF32("d_" + SysVar_Comradery);

            mem.DeclareF32(SysVar_Fame        );
            mem.DeclareF32(SysVar_SwordFame   );
            mem.DeclareF32(SysVar_Energy      );
            mem.DeclareF32(SysVar_Mind        );
            mem.DeclareF32(SysVar_Spirit      );
            mem.DeclareF32(SysVar_Shame       );
            mem.DeclareF32(SysVar_Wounds      );
            mem.DeclareF32(SysVar_Starvation  );
            mem.DeclareF32(SysVar_Food        );
            mem.DeclareF32(SysVar_Ryo         );
            mem.DeclareF32(SysVar_Drunkenness );

            mem.DeclareF32(SysVar_Upbeat      );
            mem.DeclareF32(SysVar_Joyful      );
            mem.DeclareF32(SysVar_Pleased     );
            mem.DeclareF32(SysVar_Mellow      );
            mem.DeclareF32(SysVar_Depressed   );
            mem.DeclareF32(SysVar_Disgusted   );
            mem.DeclareF32(SysVar_Angry       );
            mem.DeclareF32(SysVar_Stressed    );
            mem.DeclareF32(SysVar_Emotion);  
        }

        public static void EvalSysVars(Memory mem, Context context)
        {
            var sama        = Sama.it;
            var hero        = GameInstance.it.entity_hero;

            var ryo         = TagUtil.WealthOf(hero);
            var food        = TagUtil.FoodOf(hero) / sama.inventory.GetCap(hero.id, Kami.Inventory.Food, hero);
            var fame        = TagUtil.GetFame(context.self);
            var swordfame   = TagUtil.GetSwordmastery(context.self);
            var mind        = Sama.it.stats.GetStat(context.self, Stats.Mind);
            var spirit      = Sama.it.stats.GetStat(context.self, Stats.Spirit);
            var energy      = Sama.it.stats.GetStat(context.self, Stats.Energy);
            var shame       = Sama.it.stats.GetStat(context.self, Stats.Shame);
            var starvation  = 100 - (int)Sama.it.stats.GetCapHi(context.self, Stats.Energy);
            var wounds      = Sama.it.stats.GetStat(context.self, Stats.Wounds);
            var comradery   = 0f;
            if (null != context.other)
                comradery   = TagUtil.GetComradery(context.self, context.other);
            var drunkenness = Stats.GetIntoxication(context.self);
            // ahf: get the mood values
            var upbeat      = Sama.it.stats.GetMoodValue(context.self, Stats.Mood.Upbeat);
            var joyful      = Sama.it.stats.GetMoodValue(context.self, Stats.Mood.Joyful);
            var pleased     = Sama.it.stats.GetMoodValue(context.self, Stats.Mood.Pleased);
            var mellow      = Sama.it.stats.GetMoodValue(context.self, Stats.Mood.Mellow);
            var depressed   = Sama.it.stats.GetMoodValue(context.self, Stats.Mood.Depressed);
            var disgusted   = Sama.it.stats.GetMoodValue(context.self, Stats.Mood.Disgusted);
            var angry       = Sama.it.stats.GetMoodValue(context.self, Stats.Mood.Angry);
            var stressed    = Sama.it.stats.GetMoodValue(context.self, Stats.Mood.Stressed);
            var emotion     = Sama.it.stats.GetEmotionValue(context.self);
            
            mem.SetF32(SysVar_Ryo           , ryo);
            mem.SetF32(SysVar_Food          , food);
            mem.SetF32(SysVar_Fame          , fame);
            mem.SetF32(SysVar_SwordFame     , swordfame);
            mem.SetF32(SysVar_Mind          , mind);
            mem.SetF32(SysVar_Energy        , energy);
            mem.SetF32(SysVar_Spirit        , spirit);
            mem.SetF32(SysVar_Shame         , shame);
            mem.SetF32(SysVar_Starvation    , starvation);
            mem.SetF32(SysVar_Wounds        , wounds);
            mem.SetF32(SysVar_Comradery     , comradery);
            mem.SetF32(SysVar_Drunkenness   , drunkenness);

            mem.SetF32(SysVar_Upbeat        , upbeat);
            mem.SetF32(SysVar_Joyful        , joyful);
            mem.SetF32(SysVar_Pleased       , pleased);
            mem.SetF32(SysVar_Mellow        , mellow);
            mem.SetF32(SysVar_Depressed     , depressed);
            mem.SetF32(SysVar_Disgusted     , disgusted);
            mem.SetF32(SysVar_Angry         , angry);
            mem.SetF32(SysVar_Stressed      , stressed);
            mem.SetF32(SysVar_Emotion       , emotion);

            mem.SetStr(SysVar_Region        , TODO.CurrentRegionName(context.self.id));
            mem.SetStr(SysVar_LocationType  , Sama.it.entity_state.GetState(context.self.id) == EntityState.STATE.DISTRICT ? "District" : "Region");
            mem.SetStr(SysVar_Location      , TODO.HeroDistrictOrRegion());
            mem.SetI32(SysVar_HeadCount     , GameInstance.it.head_count);
            mem.SetI32(SysVar_Hour          , TODO.ClockTime());
        }


        public static void EvalExprs(Memory mem, Context context,
                                     FixedArray<Expression> exprs, bool [] restab)
        {
            var expno = exprs.count;
            // lock cache
            VM._record = true;
            for (int i = 0; i < expno; ++i) {
                restab[i] = VM.Eval(exprs[i], mem, context) == 1;
            }
            VM._record = false;
            // free cache
        }

        public static void EvalExprs(Memory mem, FixedArray<Expression> exprs, StreamBuffer bfr, Context context)
        {
            EvalSysVars(mem, context);
            var expno = exprs.count;
            if (bfr.condres == null || (expno > bfr.condres.Length)) {
                bfr.condres = new bool[expno];
            }
            EvalExprs(mem, context, exprs, bfr.condres);
        }


        public static bool EventsContainId(Event events, int e) {
            //TODO(psj): _defined_events sucks.
            return (Compiler._defined_events[events.index] & (ulong)(1 << e)) != 0;
        }

        public static bool EventsContainTokenizedEvent(Event events, int token) {
            return (Compiler._defined_events[events.index]
                    & Compiler._defined_events[token & Mask_TokenLData]) != 0;
        }

        public static bool EventsIsId(Event events, int e) {
            // return (events.data & (1 << e)) != 0;
            var event_val = (ulong)(1 << e);
            return event_val != 0 && (Compiler._defined_events[events.index] & event_val) == event_val;
        }

        public static bool EventsIsTokenizedEvent(Event events, int token) {
            var tokenized_event = Compiler._defined_events[token & Mask_TokenLData];
            return tokenized_event != 0 && (Compiler._defined_events[events.index] & tokenized_event) == tokenized_event;
        }


        public static void Traverse(Program prg, StreamBuffer bfr, Context context, QueryResult retq)
        {
#if DEBUG_LOG_TRAVERSE_TIME
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();
#endif
            var forest  = prg.forest;
            var state   = new TraverseState(0, VALUE.PENDING);
            // TODO(psj): what's the forest's depth?
            var tstack  = new FixedStack<TraverseState>(8);
            var running = true;
            var linkmet = false;

            while (running) {
                var token = forest[state.index];
                var ttype = token >> Shift_Cat;

                if (state.val == VALUE.RUNNING) {
                    state = tstack.Pop();
                    retq.Push(state.index);
                    var nextindex = state.index + (forest[state.index] & Mask_TokenLData);
                    if (nextindex < forest.Count && retq.count < retq.capacity) {
                        state = new TraverseState(nextindex, VALUE.PENDING);
                    } else {
                        running = false;
                    }
                } else if (ttype == Compiler.TokenId_Header) {
                    linkmet = false;
                    if (state.val == VALUE.PENDING) {
                        tstack.Push(state);
                        state = new TraverseState(state.index + 1, VALUE.PENDING);
                    } else if (state.val == VALUE.FAILURE) {
                        var nextindex = state.index + (forest[state.index] & Mask_TokenLData);
                        if (nextindex < forest.Count) {
                            state = new TraverseState(nextindex, VALUE.PENDING);
                        } else {
                            running = false;
                        }
                    }
                } else if (ttype == Compiler.TokenId_ID) {
                    if (bfr.next != null && bfr.next.Has(token & Mask_TokenData)) {
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    } else {
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                    }
                } else if (ttype == Compiler.TokenId_Tale) {
                    if (bfr.condres[token & Mask_TokenData]) {
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    } else {
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                    }
                } else if (bfr.next != null && !linkmet && ttype > Compiler.TokenId_ID) {
                    if (((forest[state.index-1] >> Shift_Cat) & Mask_Cat) != Compiler.TokenId_ID) {
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                    } else {
                        linkmet = true;
                    }
                } else if (ttype == Compiler.TokenId_Actor) {
                    if (bfr.actor == prg.actor_types[token & Mask_TokenData] || linkmet) {
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    } else {
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                    }
                } else if (ttype == Compiler.TokenId_Weight) {
                    state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                } else if (ttype == Compiler.TokenId_Precond) {
                    if (bfr.condres[token & Mask_TokenData]) {
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    } else {
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                    }
                } else if (ttype >  Compiler.TokenId_Precond) {
                    // Conditions (if any) passed, select as a Runner
                    state = new TraverseState(state, VALUE.RUNNING);
                } else {
                    Zen.Logger.LogErrorFormat("unsupported token {0:X} with type: {1}", token, ttype);
                    running = false;
                }
            }
#if DEBUG_LOG_TRAVERSE_TIME
            sw.Stop();
            Zen.Logger.LogFormat("<color=red>Found {0} answers in {1} ms ({2} ticks)</color>", 
                                retq.count, sw.ElapsedMilliseconds, sw.ElapsedTicks);
#endif
        }

        public static void TraverseRonin(ProgramRonin prg, StreamBuffer bfr, Context context, QueryResult retq)
        {
            // Program must be able to provide DELTA VALUES
#if DEBUG_LOG_TRAVERSE_TIME
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();
#endif
            var forest  = prg.forest;
            var state   = new TraverseState(0, VALUE.PENDING);
            // TODO(psj): what's the forest's depth?
            var tstack  = new FixedStack<TraverseState>(8);
            var running = true;
            var linkmet = false;
            while (running)
            {
                var token = forest[state.index];
                var ttype = token >> Shift_Cat;

                if (state.val == VALUE.RUNNING)
                {
                    state = tstack.Pop();
                    retq.Push(state.index);
                    var nextindex = state.index + (forest[state.index] & Mask_TokenLData);
                    if (nextindex < forest.Count && retq.count < retq.capacity)
                        state = new TraverseState(nextindex, VALUE.PENDING);
                    else
                        running = false;
                }
                else if (ttype == Compiler.TokenId_Header)
                {
                    linkmet = false;
                    if (state.val == VALUE.PENDING)
                    {
                        tstack.Push(state);
                        state = new TraverseState(state.index + 1, VALUE.PENDING);
                    }
                    else if (state.val == VALUE.FAILURE)
                    {
                        var nextindex = state.index + (forest[state.index] & Mask_TokenLData);
                        if (nextindex < forest.Count)
                            state = new TraverseState(nextindex, VALUE.PENDING);
                        else
                            running = false;
                    }
                }
                else if (ttype == Compiler.TokenId_Ronin_ID)
                {
                    if (bfr.next != null && bfr.next.Has(token & Mask_TokenData))
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    else
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                }
                else if (bfr.next != null && !linkmet && ttype > Compiler.TokenId_ID)
                {
                    if (((forest[state.index-1] >> Shift_Cat) & Mask_Cat) != Compiler.TokenId_ID)
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                    else
                        linkmet = true;
                }
                else if (ttype == Compiler.TokenId_Ronin_OnEvent)
                {
                    if (EventsContainTokenizedEvent(bfr.events, token))
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    else
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                }
                else if (ttype == Compiler.TokenId_Ronin_Precond)
                {
                    if (bfr.condres[token & Mask_TokenData])
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    else
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                }
                else if (ttype == Compiler.TokenId_Ronin_PartyCooldown)
                {
                    var headid = tstack.Peek();                    
                    if (prg.IsCool(headid.index) || prg.CoolDown(headid.index) == 0)
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    else
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                }
                else if (ttype == Compiler.TokenId_Ronin_Weight)
                {
                    state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                }
                else if (ttype == Compiler.TokenId_Ronin_RepeatCooldown)
                {
                    var headid = tstack.Peek();                    
                    if (prg.IsCool(context.self, headid.index) || prg.CoolDown(context.self, headid.index) == 0)
                        state = new TraverseState(state.index + 1, VALUE.SUCCESS);
                    else
                        state = new TraverseState(tstack.Pop(), VALUE.FAILURE);
                }
                else if (ttype >  Compiler.TokenId_Ronin_RepeatCooldown)
                {
                    state = new TraverseState(state, VALUE.RUNNING);
                }
                else
                {
                    Zen.Logger.LogErrorFormat("unsupported token {0:X} with type: {1}", token, ttype);
                    running = false;
                }
            }

#if DEBUG_LOG_TRAVERSE_TIME
            sw.Stop();
            Zen.Logger.LogFormat("<color=red>Found {0} answers in {1} ms ({2} ticks)</color>", 
                                retq.count, sw.ElapsedMilliseconds, sw.ElapsedTicks);
#endif
        }

        public static int GetUsableNo(QueryResult q, Forest forest) {
            int weight = 0, i = 0;
            for (; i < q.count; ++i) {
                var at  = q[i];
                var r   = at;
                var w   = 0;
                do {
                    ++r;
                    var rt = forest[r];
                    if (((rt >> Shift_Cat) & Mask_Cat) == Compiler.TokenId_Weight) {
                        w = w + (rt & Mask_TokenData);
                    } else if (((rt >> Shift_Cat) & Mask_Cat) == Compiler.TokenId_ID) {
                        w = w + 1;
                    }
                } while (((forest[r] >> Shift_Cat) & Mask_Cat) < Compiler.TokenId_Weight);
                if (w < weight) {
                    break;
                }
                weight = w;
            }
            return i;
        }

        public static int GetUsableNoRonin(QueryResult q, Forest forest)
        {
            int weight = 0, i = 0;

            for (; i < q.count; ++i)
            {
                var at  = q[i];
                var r   = at;
                var w   = 0;

                do 
                {
                    ++r;

                    var rt = forest[r];
                    if (((rt >> Shift_Cat) & Mask_Cat) == Compiler.TokenId_Ronin_Weight)
                        w = w + (rt & Mask_TokenData);
                    else if (((rt >> Shift_Cat) & Mask_Cat) == Compiler.TokenId_Ronin_ID)
                        w = w + 1;
                } while (((forest[r] >> Shift_Cat) & Mask_Cat) < Compiler.TokenId_Ronin_Weight);

                if (w < weight)
                    break;

                weight = w;
            }

            return i;
        }

        public static void LogSubTree(Program prg, int i, string fmt = "{0}", int info = 0)
        {
            var run = true;
            var sb  = new StringBuilder();
            while (run)
            {
                if (i < prg.forest.Count)
                {
                    var token = prg.forest[i++];
                    switch (token >> 24)
                    {
                    case Compiler.TokenId_ID                    : sb.AppendFormat("<color=purple>ID</color>: {0}, "             , token & Mask_TokenData); break;
                    case Compiler.TokenId_Actor                 : sb.AppendFormat("<color=purple>Actor</color>: {0}, "          , prg.actor_types[token & Mask_TokenData]); break;
                    case Compiler.TokenId_Weight                : sb.AppendFormat("<color=purple>Weight</color>: {0}, "         , token & Mask_TokenData); break;
                    case Compiler.TokenId_Precond               : sb.AppendFormat("<color=purple>Precond</color>: {0}, "        , prg.exprs[token & Mask_TokenData].ToString()); break;
                    case Compiler.TokenId_PreEncounterDialog    : sb.AppendFormat("<color=purple>PreEncounter</color>: {0}, "   , prg.mem.GetConstStr(token)); break;
                    case Compiler.TokenId_Question              : sb.AppendFormat("<color=purple>Question</color>: {0}, "       , prg.mem.GetConstStr(token)); break;
                    case Compiler.TokenId_YesText               : sb.AppendFormat("<color=purple>YesText</color>: {0}, "        , prg.actions[token & Mask_TokenData].text); break;
                    case Compiler.TokenId_NoText                : sb.AppendFormat("<color=purple>NoText</color>: {0}, "         , prg.actions[token & Mask_TokenData].text); break;
                    case Compiler.TokenId_DynamicCondition      : sb.AppendFormat("<color=purple>Precond</color>: {0}, "        , prg.exprs[token & Mask_TokenData].ToString()); break;
                    case Compiler.TokenId_DynamicText           : sb.AppendFormat("<color=purple>DynText</color>: {0}, "        , prg.actions[token & Mask_TokenData].text); break;
                    case Compiler.TokenId_PostEncounterDialog   : sb.AppendFormat("<color=purple>Postdialog</color>: {0}, "     , prg.mem.GetConstStr(token)); break;
                    case Compiler.TokenId_LogDialog             : sb.AppendFormat("<color=purple>LogDialog</color>: {0}"        , prg.mem.GetConstStr(token)); break;
                    case Compiler.TokenId_Header                :
                    {
                        if (sb.Length > 0) 
                        {
                            run = false;
                            Zen.Logger.LogFormat(fmt, sb.ToString(), info);
                        }
                    }   break;
                    }
                }
                else
                    run = false;
            }
        }

        public static void LogForest(Program prg)
        {
            int n = 0;
            for (int i = 0; i < prg.forest.Count;)
            {
                LogSubTree(prg, i, "{1} -- {0}", n++);
                i += prg.forest[i] & 0xFFFFFF;
            }
        }

        public static void LogProgramInfo(Program prg)
        {
            Zen.Logger.LogFormat("<color=blue>PROGRAM INFO: Forest Size: {0} - Expressions: {1} - Actions: {2} - Const_Strs: {3} - Const_I32s: {4} - Const_F32s: {5}</color>", 
                                prg.forest.Count, prg.exprs.count, prg.actions.count,
                                prg.mem.const_str.count, prg.mem.const_i32.count, prg.mem.const_f32.count);
        }


        public static int TraverseAndGetUsableNo(Program prg, StreamBuffer bfr, Context ctx, QueryResult result)
        {
            result.Clear();
            Traverse(prg, bfr, ctx, result);
            return (result.count > 0) ? GetUsableNo(result, prg.forest) : -1;
        }

        public static int TraverseAndGetRandomHeader(Program prg, StreamBuffer bfr, Context ctx, QueryResult result)
        {
            var usable = TraverseAndGetUsableNo(prg, bfr, ctx, result);
            return usable < 0 ? -1 : result[Kami.Sama.it.random.Limit(usable)];
        }

        public static int TraverseRoninAndGetUsableNo(ProgramRonin prg, StreamBuffer bfr, Context ctx, QueryResult result)
        {
            result.Clear();
            TraverseRonin(prg, bfr, ctx, result);
            return (result.count > 0) ? GetUsableNoRonin(result, prg.forest) : -1;
        }

        public static int TraverseRoninAndGetRandomHeader(ProgramRonin prg, StreamBuffer bfr, Context ctx, QueryResult result)
        {
            var usable = TraverseRoninAndGetUsableNo(prg, bfr, ctx, result);
            return usable < 0 ? -1 : result[Kami.Sama.it.random.Limit(usable)];
        }


        public struct SymbolFormatArgs {
            public string raw;
            public FixedArray<Entity> entities;
            public static readonly SymbolFormatArgs Empty = new SymbolFormatArgs();
        };
        public delegate string SymbolFormatter(SymbolFormatArgs fp, Context context, Memory mem);

        public static readonly SymbolFormatter
        FormatterDefault = (SymbolFormatArgs fp, Context context, Memory mem) => {
            string symbol_value = null;
            if      (fp.raw == SS_PlayerName  ) symbol_value = TagUtil.NameOf(GameInstance.it.entity_hero);
            else if (fp.raw == SS_SelfName    ) symbol_value = TagUtil.NameOf(context.self);
            else if (fp.raw == SS_OtherName   ) symbol_value = TagUtil.NameOf(context.other);
            else if (fp.raw == SS_Location    ) symbol_value = TODO.HeroDistrictOrRegion();
            // Must be trying to stringize a user-defined variable:
            else symbol_value = VM.AsStr(mem.GetAddr(fp.raw), mem);
            return symbol_value;
        };
        
        public static ParamString CreateParamString(string text,
                                                    Context context, Memory mem,
                                                    SymbolFormatter fmtr, SymbolFormatArgs sfargs,
                                                    int file_id = -1, int line_id = -1, int token_id = -1)
        {
            ParamString pstring;
            // Count symbols
            int ss_count = 0;
            for (int j = 0; j < text.Length; ++j)
                if (text[j] == '$')
                    ss_count++;
            ss_count /= 2;
            pstring = new ParamString(text, file_id, line_id, token_id, ss_count);

            // Tokenize str
            int i = text.IndexOf('$');
            if (i >= 0) {
                int symbol_start = -1;
                for (; i < text.Length; ++i) {
                    var c = text[i];
                    if (c == '$') {
                        if (symbol_start == -1) {
                            symbol_start = i;
                        } else {
                            var symbolstr = text.Substring(symbol_start, i - symbol_start + 1);
                            var symbol = symbolstr.Substring(1, symbolstr.Length - 2);
                            symbol = Str.Intern(symbol);
                            var args = new SymbolFormatArgs() {
                                raw = symbol,
                                entities = sfargs.entities
                            };
                            var symbol_value = fmtr(args, context, mem);

                            pstring.param_dic[symbolstr] = symbol_value;
                            symbol_start = -1;
                        }
                    }
                }
            }

            return pstring;
        }

        public static string CreateDisplayString(ParamString pstring, bool localize)
        {
            var text = pstring.loc_data.str_key;

            // look up translation if asked to:
            if (localize)
            {
                var translation = Sama.it.localization.GetTextFromToken(pstring.loc_data);
                if (null != translation)
                    text = translation;
            }

            if (pstring.parameterized)
            {
                foreach (var entry in pstring.param_dic)
                {
                    text = text.Replace(entry.Key, entry.Value);
                }
            }

            return text;
        }
    }
}
