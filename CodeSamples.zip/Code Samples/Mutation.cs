﻿using System.Collections.Generic;
using UnityEngine;
using Tor.Util;


namespace Zen.Mutations
{
	public interface ICondition {
		int weight {get;}
		bool Pass(State state, Mutation mutation);
        void CopyTo(ICondition to, GameObject root);
	}

	public interface IModifier {
		void Run();
	}

	public interface IOrganizer {
        int GetOrder();
		void Organize(State state);
	}


    public interface RNG {
        bool UniDice(float c);
        int Limit(int hi_exclusive);
    }

    public class RNGDefault : RNG {
        public bool UniDice(float c) => Util.ZenRand.UniDice(c);
        public int Limit(int hi_exclusive) => Util.ZenRand.Rand(hi_exclusive);
    }

    public class RNGPCG : Mutations.RNG {
        private Tor.Util.Random.PCG state;


        public RNGPCG(uint seed) {
            state = new Tor.Util.Random.PCG();
            Tor.Util.Random.Seed(state, seed);
        }

        public bool UniDice(float c) => Tor.Util.Random.Nextf(state)  < c;
        public int Limit(int hi) => Tor.Util.Random.Next(state, hi);
    }



	public class State
	{
        static readonly Tor.Benzaiten.Memory.StrRefEqualityComparer StrRefComp = new Tor.Benzaiten.Memory.StrRefEqualityComparer();

        public RNG rng;

		public List<Mutation> current;// {get; private set;}
		public List<Mutation> previous;// {get; private set;}
		private Dictionary<string, bool> _flags;


		public State() {
            rng      = new  RNGDefault();
			current  = new List<Mutation>(128);
            previous = new List<Mutation>(128);
			_flags   = new Dictionary<string, bool>(StrRefComp);
		}

		public virtual void MutationStateChanged(Mutation mutation, bool active) {
			if (active) {
				current.Add(mutation);
            }
		}

		public virtual void RemoveFromCurrent(Mutation m) {
			m.Select(false);
			current.Remove(m);
		}

		public virtual void Clear() {
			_flags.Clear();
            previous.Clear();
            for (int i = 0; i < current.Count; ++i) {
                previous.Add(current[i]);
            }
            current.Clear();
		}

		public void SetFlagValue(string flag, bool value) {
            flag = Str.Intern(flag);
			_flags[flag] = value;
		}

		public bool GetFlagValue(string flag) {
            flag = Str.Intern(flag);
			bool value;
			_flags.TryGetValue(flag, out value);
			return value;
		}

        public void Reset() {
            _flags.Clear();
            previous.Clear();
            current.Clear();
        }
	}


	public abstract class Mutation : MonoBehaviour
	{
        // Any node in a Mutant is a Mutation.
        // It can containt infinite number of Mutations as its children.

        public string token;
		public string category;


        public int intern_id {get; set;}
		public abstract bool selected {get;}
		public abstract ICondition[] conditions {get;}

        public bool token_valid {get {return !string.IsNullOrEmpty(token);} }

        private int _cweight = -1;
        private bool _weightcalced = false;
		public int conditions_weight {
			get {
                if (!_weightcalced) {
                    int weight = 0;
                    var condcache = conditions;
				    if (null != condcache) {
				    	for (int i = 0; i < condcache.Length; ++i) {
				    		weight += condcache[i].weight;
                        }
                    }
				    _cweight = weight;
                    _weightcalced = true;
                }
                return _cweight;
			}
		}

		public virtual List<Mutation> sorted_mutchildren {
			get {
				var ret = GetMutationChildren();
                if (null != ret) {
                    // The method used above to traverse the children of this Transform
                    // does not result in a the same order of objects every time. We sort by an id
                    // in order to be able to recreate a Mutation via its seed over and over again.
                    for (int i = 1; i < ret.Count; ++i) {
                        var iv = ret[i];
                        int less_index = i;
                        for (int j = i - 1; j >= 0; --j) {
                            if (iv.intern_id < ret[j].intern_id) {
                                less_index = j;
                            } else {
                                break;
                            }
                        }
                        for (int k = i; k > less_index; --k) {
                            ret[k] = ret[k - 1];
                        }
                        ret[less_index] = iv;
                    }
                }
				return ret;
			}
		}

        protected List<Mutation> __childcache;
        protected virtual List<Mutation> GetMutationChildren() {
            List<Mutation> ret = null;
            if (__childcache == null) {
                foreach (var child in transform) {
                    var mutation = ((Transform)child).GetComponent<Mutation>();
                    if ((null != mutation) && mutation.gameObject.activeSelf) {
                        if (ret == null) {
                            ret = new List<Mutation>();
                        }
                        ret.Add(mutation);
                    }
                }

                if (null != ret) {
                    ret.Remove(this);
                    SortByName(ret);
                }
                __childcache = ret;
            } else {
                ret = __childcache;
            }
            return ret;
        }

        protected static void SortByName(List<Mutation> mutations)
        {
            for (int i = 1; i < mutations.Count; ++i) {
                var iv = mutations[i];
                int less_index = i;
                for (int j = i - 1; j >= 0; --j) {
                    if (iv.gameObject.name.CompareTo(mutations[j].gameObject.name) < 0) {
                        less_index = j;
                    } else {
                        break;
                    }
                }
                for (int k = i; k > less_index; --k) {
                    mutations[k] = mutations[k - 1];
                }
                mutations[less_index] = iv;
            }
            for (int i = 0; i < mutations.Count; ++i) {
                mutations[i].intern_id = i;
            }
        }


		public abstract void Select(bool active);


        public virtual void FromTokenList(FixedArray<string> tokens)
        {
			var cached_children = sorted_mutchildren;
            if (null != cached_children) {
                foreach (var child in cached_children) {
                    child.FromTokenList(tokens);
                }
            }

            // This Mutation will be selected either if it doesn't rely on a token (empty token)
            // or its token is contained in the list passed to it.
            var should_pass = !token_valid || tokens.FirstIndex(token) >= 0;

            Select(should_pass);
        }

		public void Pulse(State state)
		{
			var pass = true;

			var cached_conditions = this.conditions;
			if (null != cached_conditions)
				for (int i = 0; pass && i < cached_conditions.Length; ++i)
					pass = cached_conditions[i].Pass(state, this);

			Select(pass);

			state.MutationStateChanged(this, selected);

            // Pulse child-mutations, lighter children are Pulsed first.
            // The sorting is done to be able to maintain dependencies among children.
            // If selection of child B depends on the selection of child A, child B
            // can be made heavier than A in order or ensure the conditions are checked in correct order.
            // ConditionPaperweight is used to adjust and the weight of Mutations if necessary.
            // TODO(psj): cache childern. although caching will require a copy for the shuffle algo!
			var cached_children = sorted_mutchildren;
            if (null != cached_children) {
                // lighter children first
                for (int i = 1; i < cached_children.Count; ++i) {
                    var iv = cached_children[i];
                    int less_index = i;
                    for (int j = i - 1; j >= 0; --j) {
                        if (iv.conditions_weight < cached_children[j].conditions_weight) {
                            less_index = j;
                        } else {
                            break;
                        }
                    }
                    for (int k = i; k > less_index; --k) {
                        cached_children[k] = cached_children[k - 1];
                    }
                    cached_children[less_index] = iv;

                }
                ShuffleWeightGroups(cached_children, state);
                for (int i = 0; i < cached_children.Count; ++i)
                    cached_children[i].Pulse(state);
            }
        }

		private static void ShuffleWeightGroups(List<Mutation> list, State state)
		{
			if (list.Count > 0) {
				var view = new Util.ViewList<Mutation>(null, 0, 0);
				while (view.start + view.length < list.Count) {
					var index  = view.start + view.length;
					var weight = list[index].conditions_weight;

                    //TODO(psj): inline this function.
					view = Util.ViewList<Mutation>.Slice(list, e => e.conditions_weight==weight, index);

                    // shuffle the same-weights
                    for (int n = view.length - 1; n > 0; --n) {
                        var r = state.rng.Limit(n + 1);
                        var t = view[n];
                        view[n] = view[r];
                        view[r] = t;
                    }
				}
			}
		}


        public virtual void CopyTo(Mutation c, GameObject root) {
            c.token = token;
            c.category = category;
        }
	}

    public abstract class MutantHead : Mutation
    {
        // A "Head" is always active - hence the empty Select function & the true selected field.
        // This is used for parenting Mutations such as Dialog Torso or the Environment
        // Where the top-most node (Mutation) is always active and acts as a command center to
        // its children.

        public bool non_mutant_branches = true;
        public State state {get; protected set;}
        public override bool selected {get {return true;} }
        public override ICondition[] conditions { get { return null; } }


        protected virtual void Awake() {
			state = new State();
        }


        public override void Select(bool active) {}


        public void SetStateRNG(RNG rng) {
            state.Reset();
            state.rng = rng;
        }

        protected void SetFlags(State s, params Tor.Util.Pair<string, bool>[] flags) {
            if (null != flags) {
                for (int i = 0; i < flags.Length; ++i) {
                    s.SetFlagValue(flags[i].first, flags[i].second);
                }
            }
        }

        List<IOrganizer> __organizers;
        private void SortAndCacheOrganizers() {
            __organizers = new List<IOrganizer>();
            GetComponents<IOrganizer>(__organizers);
            for (int i = 1; i < __organizers.Count; ++i) {
                var iv = __organizers[i];
                int less_index = i;
                for (int j = i - 1; j >= 0; --j) {
                    if (iv.GetOrder() < __organizers[j].GetOrder()) {
                        less_index = j;
                    } else {
                        break;
                    }
                }
                for (int k = i; k > less_index; --k) {
                    __organizers[k] = __organizers[k - 1];
                }
                __organizers[less_index] = iv;
            }
        }

        protected void RunOrganizers(State s) {
            if (null == __organizers) {
                SortAndCacheOrganizers();
            }
            var organizers = __organizers;
            for (int i = 0; i < organizers.Count; ++i) {
                organizers[i].Organize(s);
            }
        }

        protected void RunModifiers(State s) {
            for (int i = 0, n = s.current.Count; i < n; ++i) {
                //URGENT(psj): reduce memory consumption
                var modifiers = s.current[i].GetComponents<IModifier>();
                if (null != modifiers) {
                    for (int j = 0; j < modifiers.Length; ++j) {
                        modifiers[j].Run();
                    }
                }
            }
        }

        protected virtual void PrePulse(State s, params Tor.Util.Pair<string, bool>[] flags) {
            SetFlags(s, flags);
        }

        protected virtual void PostPulse(State s) {
            RunOrganizers(s);
        }

        public virtual void Recompose(params Tor.Util.Pair<string, bool>[] flags) {
            state.Clear();
            PrePulse(state, flags);
            Pulse(state);
            PostPulse(state);
        }

        protected override List<Mutation> GetMutationChildren() {
            if (non_mutant_branches) {
                if (__childcache == null) {
                    __childcache = new List<Mutation>();
                } else {
                    __childcache.Clear();
                }
                GetComponentsInChildren<Mutation>(false, __childcache);
                if (null != __childcache) {
                    __childcache.Remove(this);
                    SortByName(__childcache);
                }
                return __childcache;
            } else {
                return base.GetMutationChildren();
            }
        }
    }
}
