﻿namespace Tor.Util
{
    using u32 = System.UInt32;
    using u64 = System.UInt64;


    internal static class RNG_Internals
    {
        internal static float normalized_float_from_u32(u32 v)
        {
            int res = (int)((0x7F << 23) | (v >> 9));
            return System.BitConverter.ToSingle(System.BitConverter.GetBytes(res), 0) - 1f;
        }

        internal static u32 murmur3_avalanche32(u32 h)
        {
            h ^= h >> 16;
            h *= 0x85EBCA6B;
            h ^= h >> 13;
            h *= 0xC2B2AE35;
            h ^= h >> 16;
            return h;
        }

        internal static u64 murmur3_avalanche64(u64 h)
        {
            h ^= h >> 33;
            h *= 0XFF51AFD7ED558CCD;
            h ^= h >> 33;
            h *= 0XC4CEB9FE1A85EC53;
            h ^= h >> 33;
            return h;
        }
    }


    public static class Random
    {    
        public class PCG {public u64[] data = new u64[2];}

        
        public static void Seed(PCG pcg, u32 seed)
        {
            var value = (((u64)seed) << 1)| 1UL;
            value = RNG_Internals.murmur3_avalanche64(value);
            pcg.data[0] = 0UL;
            pcg.data[1] = (value << 1) | 1UL;
            Next(pcg);
            pcg.data[0] += RNG_Internals.murmur3_avalanche64(value);
            Next(pcg);
        }
        
		public static u32 Next(PCG pcg)
        {
            var oldstate = pcg.data[0];
            pcg.data[0] = oldstate * 0X5851F42D4C957F2DUL + pcg.data[1];
            var xorshifted = (u32)(((oldstate >> 18) ^ oldstate) >> 27);
            var rot = (int)(oldstate >> 59);
            return (xorshifted >> rot) | (xorshifted << ((-(int)rot) & 31));
        }
        
		public static int Next(PCG pcg, int hi_exclusive)
        {
            var limit = 0xFFFFFFFF - (0xFFFFFFFF % hi_exclusive);
            var ret = Next(pcg);
            while (ret >= limit)
                ret = Next(pcg);
            return (int)(ret % hi_exclusive);
        }
        
		public static int Next(PCG pcg, int min, int max)
        {
            var range_size = max - min + 1;
            if (range_size <= 0) return min;
            return min + (int)(range_size * Nextf(pcg));
        }
        
		public static float Nextf(PCG pcg)
        {
            return (float)(Next(pcg) / (double)(0xFFFFFFFF));
        }
        
		public static float Nextf_RightOpen(PCG pcg)
        {
            return (float)(Next(pcg) / (double)(0x100000000));
        }
		
        public static float Nextf(PCG pcg, float lo_inclusive, float hi_inclusive) 
        {
            if (lo_inclusive <= hi_inclusive)
                return Nextf(pcg) * (hi_inclusive - lo_inclusive) + lo_inclusive;
            else
                return Nextf(pcg) * (lo_inclusive - hi_inclusive) + hi_inclusive;
        }
		
        public static float Nextf_RightOpen(PCG pcg, float lo_inclusive, float hi_exclusive)
        {
            if (lo_inclusive <= hi_exclusive)
                return Nextf_RightOpen(pcg) * (hi_exclusive - lo_inclusive) + lo_inclusive;
            else
                return Nextf_RightOpen(pcg) * (lo_inclusive - hi_exclusive) + hi_exclusive;
        }
    }
}
