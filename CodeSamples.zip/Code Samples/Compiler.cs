#define IGNORE_MISOPS
// #define ASSERT_MISOPS
#define VM_FIXED_MEM
// #define DOT_VM_COUNT

using System.Runtime.CompilerServices;


namespace Dot.Scripting {
    using Util;

    using static Ops;
    using static Syntax;
    using static Internals;

    using i32 = System.Int32;
    using f32 = System.Single;
    using str = System.String;

    /*
     * TODO(psj):
     * * * investigate float-int comparison
     * * * investigate float-float comparison
     */

    public partial class VM {
        public struct Args {
            public Expression expr;
            public Memory mem;
            public RNPI rnp;
            public Context context;
        }
        
        private FixedStack<int> stack;
        private FixedStack<int> args;

#if VM_FIXED_MEM
        private static FixedStack<int> s_stack = new FixedStack<int>(32);
        private static FixedStack<int> s_args  = new FixedStack<int>(32);
#endif


        public VM(int stack_size, int args_size) {
            stack = new FixedStack<i32>(stack_size);
            args  = new FixedStack<i32>(args_size);
        }


        public int Eval(Args iargs) {
            stack.Clear();
            args.Clear();
            return __Eval(iargs, stack, args);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int EvalAsI32(Args iargs) {
            return AsI32(Eval(iargs), iargs.mem);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float EvalAsF32(Args iargs) {
            return AsF32(Eval(iargs), iargs.mem);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public string EvalAsStr(Args iargs) {
            return AsStr(Eval(iargs), iargs.mem);
        }
        
        public static int __Eval(Args iargs,
                                 FixedStack<int> stack = null,
                                 FixedStack<int> args = null)
        {
            Expression expr = iargs.expr;
            Memory mem      = iargs.mem;
            RNPI rnp        = iargs.rnp;
            Context context = iargs.context;

            if (null == stack) {

#if VM_FIXED_MEM
                stack = s_stack;
#else
                stack = new FixedStack<int>(expr.length);
#endif
            }
            if (null == args) {

#if VM_FIXED_MEM
                args = s_args;
#else
                args = new FixedStack<int>(expr.length);
#endif
            }

#if VM_FIXED_MEM
            bool __clean_stack = stack.empty;
            bool __clean_args  = args.empty;
#endif

            for (int __ti = 0, __tin = expr.length; __ti < __tin; ++__ti) {
                var __t = expr.tokens[__ti];
                var __k = (__t >> Shift_Typ) & Mask_Typ;
                var __c = (__t >> Shift_Cat) & Mask_Cat;

                if (__c == Cat_Const || __c == Cat_Var || __c == Cat_Short) { // just push on stack if it's a value
                    if (__k == Type_Runtime)
                        __t = mem.GetAddr(mem.rts[__t & Mask_VarAddr]);
                    stack.Push(__t);
                } /*else if (((__c >> 1) & 0xF) == Cat_Const || ((__c >> 1) & 0xF) == Cat_Var) { // a base value
                    stack.Push(__t);
                } */else if (__c == Cat_Op) { // an operator or a function call?
                    if (__k < Op_EndOfOperators) { // Binary operators
                        var r = stack.Pop();
                        var l = stack.Pop();

                        if (((r >> Shift_Cat) & Mask_Cat) == Cat_Stack && ((l >> Shift_Cat) & Mask_Cat) == Cat_Stack
                            && ((r >> Shift_Typ) & Mask_Typ) == ((l >> Shift_Typ) & Mask_Typ))
                        {
                            if (((r >> Shift_Typ) & Mask_Typ) == Type_I32)
                                mem.stack_i32.Swap();
                            else if (((r >> Shift_Typ) & Mask_Typ) == Type_F32)
                                mem.stack_f32.Swap();
                            else if (((r >> Shift_Typ) & Mask_Typ) == Type_Str)
                                mem.stack_str.Swap();
                        }

                        switch (__k) {
                            case Op_AND: stack.Push(l == 0 ? 0 : r == 1 ? 1 : 0);  break;
                            case Op_OR : stack.Push(l == 1 ? 1 : r == 1 ? 1 : 0);  break;
                            case Op_XOR: stack.Push(l != r ? 1 : 0);               break;
                            case Op_EQL: stack.Push(IsEqual(l, r, mem));           break;
                            case Op_NEQ: stack.Push(1 - IsEqual(l, r, mem));       break;
                            case Op_LES: stack.Push(IsLess(l, r, mem));            break;
                            case Op_LOE: stack.Push(IsLessEqual(l, r, mem));       break;
                            case Op_GRT: stack.Push(IsLess(r, l, mem));            break;
                            case Op_GOE: stack.Push(IsLessEqual(r, l, mem));       break;
                            case Op_ADD: stack.Push(Add(l, r, mem));               break;
                            case Op_SUB: stack.Push(Sub(l, r, mem));               break;
                            case Op_MUL: stack.Push(Mul(l, r, mem));               break;
                            case Op_DIV: stack.Push(Div(l, r, mem));               break;
                        }
                    } else {
                        switch (__k) {
                            // case Op_Base: {
                            //     var sym = stack.Pop();
                            //     stack.Pop(); // pop func header

                            //     var t_push = 0;

                            //     // if token is 0 (self) or 1 (other), add offset
                            //     // otherwise flag token as a base token
                            //     switch (sym) {
                            //         case 0  :
                            //         case 1  : t_push = sym + 2;         break;
                            //         default : t_push = sym | Flag_Base; break;
                            //     }

                            //     if (((t_push >> Shift_Typ) & Mask_Typ) == Type_Runtime) {
                            //         var pmem = mem.parent ?? mem;
                            //         t_push = (Flag_Base) | pmem.GetAddrSafe(mem.rts[t_push & Mask_VarAddr]);
                            //     }

                            //     stack.Push(t_push);
                            // }   break;
                            // case Op_HasBase: {
                            //     stack.Pop(); // pop func header
                            //     stack.Push(context.parent != null && context.parent.Length > 0 && mem.parent != null ? 1 : 0);
                            //     stack.Push(0);
                            // }   break;

                            case Op_JMP: {
                                var steps = GetI32(stack.Pop(), mem);
                                __ti += steps;
                            } break;

                            case Op_JEZ: {
                                var steps = GetI32(stack.Pop(), mem);
                                var compr = GetI32(stack.Pop(), mem);
                                if (compr == 0) {
                                    __ti += steps;
                                }
                            } break;

                            case Op_RET: {
                                __ti = __tin;
                            } break;

                            case Op_Neg: {
                                var value = stack.Pop();
                                PopFuncHeader(stack);
                                stack.Push(Neg(value, mem));
                            }   break;

                            case Op_Rand: {
                                var hi = AsI32(stack.Pop(), mem);
                                var lo = AsI32(stack.Pop(), mem);
                                PopFuncHeader(stack);
                                stack.Push(PushI32(rnp.Range(lo, hi), mem));
                            }   break;
                            case Op_RandF: {
                                var hi = AsF32(stack.Pop(), mem);
                                var lo = AsF32(stack.Pop(), mem);
                                PopFuncHeader(stack);
                                stack.Push(PushF32(rnp.Rangef(lo, hi), mem));
                            }   break;
                            case Op_RandF01: {
                                PopFuncHeader(stack);
                                stack.Push(PushF32(rnp.Uniform(), mem));
                            }   break;
                            case Op_RandLI: {
                                for (var p = stack.Pop(); !IsFuncHeader(p); p = stack.Pop()) {
                                    args.Push(p);
                                }
                                stack.Push(PushI32(GetI32(args.data[rnp.Limit(args.count)], mem), mem));
                            } break;
                            case Op_RandLF: {
                                for (var p = stack.Pop(); !IsFuncHeader(p); p = stack.Pop()) {
                                    args.Push(p);
                                }
                                stack.Push(PushF32(AsF32(args.data[rnp.Limit(args.count)], mem), mem));
                            } break;
                            case Op_RandLS: {
                                for (var p = stack.Pop(); !IsFuncHeader(p); p = stack.Pop()) {
                                    args.Push(p);
                                }
                                stack.Push(PushStr(GetStr(args.data[rnp.Limit(args.count)], mem), mem));
                            }   break;

                            case Op_IIF: {
                                var b = stack.Pop();
                                var a = stack.Pop();
                                var c = GetI32(stack.Pop(), mem);
                                PopFuncHeader(stack);

                                stack.Push((c != 0) ? a : b);
                            }   break;

                            case Op_DeclI32: {
                                var val = GetI32(stack.Pop(), mem);
                                var sym = mem.rts[stack.Pop() & Mask_VarAddr];
                                PopFuncHeader(stack);
                                mem.DeclareI32(sym, val);
                            }   break;
                            case Op_DeclF32: {
                                var val = GetF32(stack.Pop(), mem);
                                var sym = mem.rts[stack.Pop() & Mask_VarAddr];
                                PopFuncHeader(stack);
                                mem.DeclareF32(sym, val);
                            }   break;
                            case Op_DeclStr: {
                                var val = AsStr(stack.Pop(), mem);
                                var sym = mem.rts[stack.Pop() & Mask_VarAddr];
                                PopFuncHeader(stack);
                                mem.DeclareStr(sym, val);
                            }   break;
                            case Op_Set: {
                                var val = stack.Pop();
                                var sym = stack.Pop();
                                PopFuncHeader(stack);
                                Assert.Do(((sym >> Shift_Cat) & Mask_Cat) == Cat_Var);
                                if (IsType(sym, Type_I32))
                                    mem.SetI32(sym, AsI32(val, mem));
                                if (IsType(sym, Type_F32))
                                    mem.SetF32(sym, AsF32(val, mem));
                                if (IsType(sym, Type_Str))
                                    mem.SetStr(sym, AsStr(val, mem));
                            }   break;

                            case Op_Mod: {
                                var val = stack.Pop();
                                var sym = stack.Pop();
                                PopFuncHeader(stack);
                                Assert.Do(((sym >> Shift_Cat) & Mask_Cat) == Cat_Var);
                                if (IsType(sym, Type_I32))
                                    mem.SetI32(sym, mem.GetI32(sym) + AsI32(val, mem));
                                if (IsType(sym, Type_F32))
                                    mem.SetF32(sym, mem.GetF32(sym) + AsF32(val, mem));
                                if (IsType(sym, Type_Str))
                                    mem.SetStr(sym, mem.GetStr(sym) + AsStr(val, mem));
                            }   break;

                            case Op_Log: {
                                var str = AsStr(stack.Pop(), mem);
                                PopFuncHeader(stack);
                                Log.Msg(str);
                            }   break;

                            default: {
                                Forward(__t, __c, __k, mem, rnp, context, stack, args);
                            } break;
                        }
                    }
                } else if (__c >= TokenId_If) {
                    // skip...
                } else {
                    stack.Push(__t);
                }
            }

#if VM_FIXED_MEM
            var ret = stack.count > 0 ? stack.Pop() : 1;

#if UNITY_EDITOR && DOT_VERBOSE
            if (stack.count > 0 && __clean_stack) {
                Zen.Logger.LogFormat("<color=red>VM {0} ended with size: {1}, after: {2}, id: {3} at {4}({5})</color>",
                                     "stack", stack.count, expr.ToString(), expr.expr_id,
                                     0, 0);
            }
            if (args.count > 0 && __clean_args) {
                Zen.Logger.LogFormat("<color=red>VM {0} args stack ended with size: {1}, after: {2}, id: {3} at {4}({5})</color>",
                                     "args", args.count, expr.ToString(), expr.expr_id,
                                     0, 0);
            }
#endif
            if (__clean_stack)
                stack.Clear();
            if (__clean_args)
                args.Clear();

            return ret;
#else
            return stack.count > 0 ? stack.Pop() : 1;
#endif
        }


#if DOT_VM_COUNT
        private static System.Collections.Generic.Dictionary<Pair<string, int>, int> _hrecords =
            new System.Collections.Generic.Dictionary<Pair<string, int>, int>();
        private static System.Collections.Generic.Dictionary<Pair<Pair<string, int>, int>, int> _records =
            new System.Collections.Generic.Dictionary<Pair<Pair<string, int>, int>, int>();
#endif
        private static bool _recording;
        public static bool _record {
            get {
                return _recording;
            }
            set {
                _recording = value;
#if DOT_VM_COUNT
                if (value) {
                    _records.Clear();
                    _hrecords.Clear();
                } else {
                    foreach (var e in _hrecords) {
                        Log.MsgFormat("___{0} ({1}) total calls: {2}",
                                      e.Key.first,
                                      e.Key.second,
                                      e.Value);
                    }
                    foreach (var e in _records) {
                        Log.MsgFormat("___{0} ({1}) with {2}: {3}",
                                      e.Key.first.first,
                                      e.Key.first.second,
                                      e.Key.second,
                                      e.Value);
                    }
                }
#endif
            }
        }

        private static void __Count(string n, int k, int arg, bool just_head = false) {
#if DOT_VM_COUNT            
            var hkey = new Pair<string, int>(n, k);
            var hv = _hrecords.TryGetValue(hkey, out int hc);
            _hrecords[hkey] = hc + 1;
            if (!just_head) {
                var key = new Pair<Pair<string, int>, int>(hkey, arg);
                var v = _records.TryGetValue(key, out int c);
                _records[key] = c + 1;
            }
#endif
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static void PopFuncHeader(FixedStack<int> s) {
#if DOT_PARANOID
            var t = s.Pop();
            Assert.Do(IsFuncHeader(t));
#else
            s.Pop();
#endif
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool IsType(int token, int type) {return ((token >> Shift_Typ) & Mask_Typ) == type;}
        // [MethodImpl(MethodImplOptions.AggressiveInlining)]
        // private static bool IsSelfOrOther(int token) {return ((token >> Shift_Typ)/* & 0xFFFF*/) == 0;}
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool IsFuncHeader(int token) {return ((token >> Shift_Cat) & Mask_Cat) == TokenId_FuncHeader;}


        public static i32 GetI32(int t, Memory mem) {
            if ((t & Mask_MSN) != 0) {
                if (mem.parent == null)
                    return 0;

                mem = mem.parent;
                t = t & Mask_EMSN;
            }

            switch ((t >> Shift_Cat) & Mask_Cat) {
                case 0        : return t & 1;
                case Cat_Const: return mem.GetConstI32(t);
                case Cat_Var  : return mem.GetI32(t);
                case Cat_Stack: return mem.PopI32();
                case Cat_Short: return t & Mask_TokenData;
                default       : return 0;
            }
        }

        public static i32 AsI32(int t, Memory mem) {
            int ret;
            var type = (t >> Shift_Typ) & Mask_Typ;
            if      (type == Type_I32)
                ret = GetI32(t, mem);
            else if (type == Type_F32)
                ret = (int)System.Math.Floor(GetF32(t, mem));
            else if (type == Type_Str)
                ret = int.Parse(GetStr(t, mem));
            else
                ret = 0;
            return ret;
        }

        public static Id AsId(int t, Memory mem) {
            return Id.Create((uint)AsI32(t, mem));
        }

        public static f32 GetF32(int t, Memory mem) {
            if ((t & Mask_MSN) != 0) {
                if (mem.parent == null) {
                    return 0;
                }

                mem = mem.parent;
                t = t & Mask_EMSN;
            }

            switch ((t >> Shift_Cat) & Mask_Cat) {
                case Cat_Const: return mem.GetConstF32(t);
                case Cat_Var  : return mem.GetF32(t);
                case Cat_Stack: return mem.PopF32();
                default       : return 0f;
            }
        }

        public static f32 AsF32(int t, Memory mem) {
            f32 ret;
            var type = (t >> Shift_Typ) & Mask_Typ;
            if      (type == Type_I32)
                ret = GetI32(t, mem);
            else if (type == Type_F32)
                ret = GetF32(t, mem);
            else if (type == Type_Str)
                TryParseFloat(GetStr(t, mem), out ret);
            else
                ret = 0;
            return ret;
        }
        

        public static str GetStr(int t, Memory mem) {
            if ((t & Mask_MSN) != 0)
            {
                if (mem.parent == null)
                    return "";

                mem = mem.parent;
                t = t & Mask_EMSN;
            }

            switch ((t >> Shift_Cat) & Mask_Cat)
            {
                case Cat_Const : return mem.GetConstStr(t);
                case Cat_Var   : return mem.GetStr(t);
                case Cat_Stack : return mem.PopStr();
                default                 : return null;
            }
        }

        public static str AsStr(int t, Memory mem) {
            str ret;
            var type = (t >> Shift_Typ) & Mask_Typ;
            if      (type == Type_I32)
                ret = GetI32(t, mem).ToString();
            else if (type == Type_F32)
                ret = GetF32(t, mem).ToString();
            else if (type == Type_Str)
                ret = GetStr(t, mem);
            else
                ret = null;
            return ret;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static int PushI32(i32 val, Memory mem) {
            mem.Push(val);
            return (Cat_Stack << Shift_Cat) | (Type_I32 << Shift_Typ);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static int PushF32(f32 val, Memory mem) {
            mem.Push(val);
            return (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static int PushStr(str val, Memory mem) {
            mem.Push(val);
            return (Cat_Stack << Shift_Cat) | (Type_Str << Shift_Typ);
        }


        private static int Neg(int t, Memory mem) {
            int ret;
            var type = (t >> Shift_Typ) & Mask_Typ;
            if (type == Type_I32)
                ret = PushI32(-GetI32(t, mem), mem);
            else if (type == Type_F32)
                ret = PushF32(-GetF32(t, mem), mem);
            else {
#if ASSERT_MISOPS
                Assert.Do(false, "Invalid operation: Neg {0}", t);
#elif !(IGNORE_MISOPS)
                Zen.Logger.LogWarningFormat("Invalid operation: Neg {0}", t);
#endif
                ret = 0;
            }
            return ret;
        }

        private static int IsEqual(int l, int r, Memory mem) {
            int ret;
            var lk = (l >> Shift_Typ) & Mask_Typ;
            var rk = (r >> Shift_Typ) & Mask_Typ;
            if (lk == Type_I32 && rk == Type_I32)
                ret = GetI32(l, mem) == GetI32(r, mem) ? 1 : 0;
            else if (lk == Type_F32 && rk == Type_I32)
                ret = GetF32(l, mem) == GetI32(r, mem) ? 1 : 0;
            else if (lk == Type_I32 && rk == Type_F32)
                ret = GetI32(l, mem) == GetF32(r, mem) ? 1 : 0;
            else if (lk == Type_F32 && rk == Type_F32)
                ret = GetF32(l, mem) == GetF32(r, mem) ? 1 : 0;
            else if (lk == Type_Str && rk == Type_Str)
                ret = GetStr(l, mem) == GetStr(r, mem) ? 1 : 0;
            else {
#if ASSERT_MISOPS
                Assert.Do(false, "Invalid operation: {0} == {1}", l, r);
#elif !(IGNORE_MISOPS)
                Zen.Logger.LogWarningFormat("Invalid operation: {0} == {1}", l, r);
#endif
                ret = 0;
            }
            return ret;
        }

        private static int IsLess(int l, int r, Memory mem) {
            int ret;
            var lk = (l >> Shift_Typ) & Mask_Typ;
            var rk = (r >> Shift_Typ) & Mask_Typ;
            if (lk == Type_I32 && rk == Type_I32)
                ret = GetI32(l, mem) < GetI32(r, mem) ? 1 : 0;
            else if (lk == Type_F32 && rk == Type_I32)
                ret = GetF32(l, mem) < GetI32(r, mem) ? 1 : 0;
            else if (lk == Type_I32 && rk == Type_F32)
                ret = GetI32(l, mem) < GetF32(r, mem) ? 1 : 0;
            else if (lk == Type_F32 && rk == Type_F32)
                ret = GetF32(l, mem) < GetF32(r, mem) ? 1 : 0;
            else {
#if ASSERT_MIOPS
                Assert.Do(false, "Invalid operation: {0} < {1}", l, r);
#elif !(IGNORE_MISOPS)
                Zen.Logger.LogWarningFormat("Invalid operation: {0} < {1}", l, r);
#endif
                ret = 0;
            }
            return ret;
        }

        private static int IsLessEqual(int l, int r, Memory mem) {
            int ret;
            var lk = (l >> Shift_Typ) & Mask_Typ;
            var rk = (r >> Shift_Typ) & Mask_Typ;
            if (lk == Type_I32 && rk == Type_I32)
                ret = GetI32(l, mem) <= GetI32(r, mem) ? 1 : 0;
            else if (lk == Type_F32 && rk == Type_I32)
                ret = GetF32(l, mem) <= GetI32(r, mem) ? 1 : 0;
            else if (lk == Type_I32 && rk == Type_F32)
                ret = GetI32(l, mem) <= GetF32(r, mem) ? 1 : 0;
            else if (lk == Type_F32 && rk == Type_F32)
                ret = GetF32(l, mem) <= GetF32(r, mem) ? 1 : 0;
            else {
#if ASSERT_MISOPS
                Assert.Do(false, "Invalid operation: {0} <= {1}", l, r);
#elif !(IGNORE_MISOPS)
                Zen.Logger.LogWarningFormat("Invalid operation: {0} <= {1}", l, r);
#endif
                ret = 0;
            }
            return ret;
        }

        private static int Add(int l, int r, Memory mem) {
            int ret;
            var lk = (l >> Shift_Typ) & Mask_Typ;
            var rk = (r >> Shift_Typ) & Mask_Typ;
            if (lk == Type_I32 && rk == Type_I32)
                ret = PushI32(GetI32(l, mem) + GetI32(r, mem), mem);
            else if (lk == Type_I32 && rk == Type_Str)
                ret = PushStr(AsStr(l, mem) + GetStr(r, mem), mem);
            else if (lk == Type_F32 && rk == Type_I32)
                ret = PushF32(GetF32(l, mem) + GetI32(r, mem), mem);
            else if (lk == Type_I32 && rk == Type_F32)
                ret = PushF32(GetI32(l, mem) + GetF32(r, mem), mem);
            else if (lk == Type_F32 && rk == Type_F32)
                ret = PushF32(GetF32(l, mem) + GetF32(r, mem), mem);
            else if (lk == Type_F32 && rk == Type_Str)
                ret = PushStr(AsStr(l, mem) + GetStr(r, mem), mem);
            else if (lk == Type_Str && rk == Type_I32)
                ret = PushStr(GetStr(l, mem) + AsStr(r, mem), mem);
            else if (lk == Type_Str && rk == Type_F32)
                ret = PushStr(GetStr(l, mem) + AsStr(r, mem), mem);
            else if (lk == Type_Str && rk == Type_Str)
                ret = PushStr(GetStr(l, mem) + GetStr(r, mem), mem);
            else {
#if ASSERT_MIOPS
                Assert.Do(false, "Invalid operation: {0} + {1}", l, r);
#elif !(IGNORE_MISOPS)
                Zen.Logger.LogWarningFormat("Invalid operation: {0} + {1}", l, r);
#endif
                ret = 0;
            }
            return ret;
        }

        private static int Sub(int l, int r, Memory mem) {
            int ret;
            var lk = (l >> Shift_Typ) & Mask_Typ;
            var rk = (r >> Shift_Typ) & Mask_Typ;
            if (lk == Type_I32 && rk == Type_I32) {
                mem.Push(GetI32(l, mem) - GetI32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_I32 << Shift_Typ);
            } else if (lk == Type_F32 && rk == Type_I32) {
                mem.Push(GetF32(l, mem) - GetI32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else if (lk == Type_I32 && rk == Type_F32) {
                mem.Push(GetI32(l, mem) - GetF32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else if (lk == Type_F32 && rk == Type_F32) {
                mem.Push(GetF32(l, mem) - GetF32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else {
#if ASSERT_MISOPS
                Assert.Do(false, "Invalid operation: {0} - {1}", l, r);
#elif !(IGNORE_MISOPS)
                Zen.Logger.LogWarningFormat("Invalid operation: {0} - {1}", l, r);
#endif
                ret = 0;
            }
            return ret;
        }

        private static int Mul(int l, int r, Memory mem) {
            int ret;
            var lk = (l >> Shift_Typ) & Mask_Typ;
            var rk = (r >> Shift_Typ) & Mask_Typ;
            if (lk == Type_I32 && rk == Type_I32) {
                mem.Push(GetI32(l, mem) * GetI32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_I32 << Shift_Typ);
            } else if (lk == Type_F32 && rk == Type_I32) {
                mem.Push(GetF32(l, mem) * GetI32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else if (lk == Type_I32 && rk == Type_F32) {
                mem.Push(GetI32(l, mem) * GetF32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else if (lk == Type_F32 && rk == Type_F32) {
                mem.Push(GetF32(l, mem) * GetF32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else {
#if ASSERT_MISOPS
                Assert.Do(false, "Invalid operation: {0} * {1}", l, r);
#elif !(IGNORE_MISOPS)
                Zen.Logger.LogWarningFormat("Invalid operation: {0} * {1}", l, r);
#endif
                ret = 0;
            }
            return ret;
        }

        private static int Div(int l, int r, Memory mem) {
            int ret;
            var lk = (l >> Shift_Typ) & Mask_Typ;
            var rk = (r >> Shift_Typ) & Mask_Typ;
            if (lk == Type_I32 && rk == Type_I32) {
                mem.Push(GetI32(l, mem) / GetI32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_I32 << Shift_Typ);
            } else if (lk == Type_F32 && rk == Type_I32) {
                mem.Push(GetF32(l, mem) / GetI32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else if (lk == Type_I32 && rk == Type_F32) {
                mem.Push(GetI32(l, mem) / GetF32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else if (lk == Type_F32 && rk == Type_F32) {
                mem.Push(GetF32(l, mem) / GetF32(r, mem));
                ret = (Cat_Stack << Shift_Cat) | (Type_F32 << Shift_Typ);
            } else {
#if ASSERT_MISOPS
                Assert.Do(false, "Invalid operation: {0} / {1}", l, r);
#elif !(IGNORE_MISOPS)
                Zen.Logger.LogWarningFormat("Invalid operation: {0} / {1}", l, r);
#endif
                ret = 0;
            }
            return ret;
        }
    }
}
