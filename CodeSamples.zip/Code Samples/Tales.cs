﻿namespace Tor.Benzaiten
{
    using Util;


    public class Tales
    {
        public Memory mem;
        public FixedArray<int> states;
        public FixedArray<int> transitions;
        public FixedArray<int> active_states;
        public FixedArray<int> transition_count;
        public FixedArray<int> transition_start;
        public FixedArray<double> activation_time;
        public FixedArray<string> guards;
        public FixedArray<string> state_names;
        public FixedArray<Expression> conds;
        public FixedArray<Expression> on_enter;
        public FixedArray<Expression> on_exit;
        public FixedQueue<Expression> expq;
        
        public FixedArray<int> tales;
        public FixedArray<string> tale_names;

        private const int MaxColSize = 1024;
        public Tales()
        {
            states              = new FixedArray<int>(MaxColSize);
            transitions         = new FixedArray<int>(MaxColSize);
            active_states       = new FixedArray<int>(MaxColSize);
            transition_count    = new FixedArray<int>(MaxColSize);
            transition_start    = new FixedArray<int>(MaxColSize);
            activation_time     = new FixedArray<double>(MaxColSize);
            guards              = new FixedArray<string>(MaxColSize);
            state_names         = new FixedArray<string>(MaxColSize);
            conds               = new FixedArray<Expression>(MaxColSize);
            on_enter            = new FixedArray<Expression>(MaxColSize);
            on_exit             = new FixedArray<Expression>(MaxColSize);
            expq                = new FixedQueue<Expression>(MaxColSize);
            
            tales               = new FixedArray<int>(MaxColSize);
            tale_names          = new FixedArray<string>(MaxColSize);
        }

        public int Insert(string state_name,
                          Expression enter_expr = new Expression(),
                          Expression exit_expr = new Expression())
        {
            state_name = Str.Intern(state_name);
            var id = states.PushAndTell(states.count);
            Assert.Do(id == state_names.PushAndTell(state_name));
            Assert.Do(id == transition_count.PushAndTell(0));
            Assert.Do(id == transition_start.PushAndTell(-1));
            Assert.Do(id == on_enter.PushAndTell(enter_expr));
            Assert.Do(id == on_exit.PushAndTell(exit_expr));
            Assert.Do(id == activation_time.PushAndTell(0.0));
            return id;
        }

        public void InsertTransition(int from, int to, string guard, Expression cond = new Expression())
        {
            var guard_id = guards.PushAndTell(guard);
            var expr_id = conds.PushAndTell(cond);

            Assert.Do(guard_id == expr_id);
            Assert.Do(guard_id == transitions.PushAndTell(to));

            transition_count[from] = transition_count[from] + 1;
        }

        public void BuildTransitions()
        {
            int t_start = 0;
            for (int i = 0; i < transition_start.count; ++i)
            {
                transition_start[i] = t_start;
                t_start = t_start + transition_count[i];
            }
        }
        
        public void DefineTale(int hi, string tale_name)
        {
            tale_name = Str.Intern(tale_name);
            var id = tales.PushAndTell(hi);
            Assert.Do(id == tale_names.PushAndTell(tale_name));
        }


        public void OnEvent(string e)
        {
            // Zen.Logger.Log("Tale event received: " + e);

            e = Str.Intern(e);
            var time_of_event = Kami.Sama.it.time.UniversalSessionTime();

            for (int i = 0; i < active_states.count; ++i)
            {
                var state_id = active_states[i];
                var t_start  = transition_start[state_id];
                if (t_start >= 0)
                {
                    var t_count = transition_count[state_id];

                    for (int j = t_start, t_len = t_start + t_count; j < t_len; ++j)
                    {
                        if (guards[j] == e
                            && (!conds[j].valid || VM.Eval(conds[j], mem) != 0))
                        {
                            if (on_exit[active_states[i]].valid)
                                expq.Push(on_exit[active_states[i]]);
                            
                            active_states[i] = transitions[j];
                            activation_time[transitions[j]] = time_of_event;
                            
                            if (on_enter[active_states[i]].valid)
                                expq.Push(on_enter[active_states[i]]);
                            
                            break;
                        }
                    }
                }
            }

            for (int i = active_states.count - 1; i >= 0; --i)
                if (transition_count[active_states[i]] == 0)
                    active_states.RemoveIndex(i);
        }

        public int GetTaleId(int state_id)
        {
            int ret = -1;
            
            int k = state_id,
                m = tales.count / 2,
                l = 0,
                h = tales.count - 1;
            while (l <= h)
            {
                if (k == tales[m])
                {
                    ret = m;
                    break;
                }
                else if (k > tales[m])
                    l = m + 1;
                else if (k < tales[m])
                {
                    ret = m;
                    h = m - 1;
                }
                m = (l + h) / 2;
            }

            return ret;
        }

        public bool GetTaleAndStateId(string tale_name, string state_name, out int tale_id, out int state_id)
        {
            bool ret = false;

            tale_name = Str.Intern(tale_name);
            state_name = Str.Intern(state_name);

            tale_id = state_id = -1;

            for (int i = 0; !ret && i < tale_names.count; ++i)
                if (tale_names[i] == tale_name)
                {
                    tale_id = i;

                    for (int j = states[tales[tale_id]]; !ret && j >= 0; --j)
                        if (state_names[j] == state_name)
                        {
                            state_id = j;
                            ret = true;
                        }
                }

            return ret;
        }

        public bool IsTaleStateActive(string tale_name, string state_name, out int tale_id, out int state_id)
        {
            bool ret = false;

            if (GetTaleAndStateId(tale_name, state_name, out tale_id, out state_id))
                for (int i = 0; !ret && i < active_states.count; ++i)
                {
                    if (active_states[i] == state_id)
                        ret = true;
                }

            return ret;
        }

        public bool IsTaleStateActive(string tale_name, string state_name)
        {
            int tale_id, state_id;
            return IsTaleStateActive(tale_name, state_name, out tale_id, out state_id);
        }

        public bool IsTaleAwake(string tale_name)
        {
            var ret = false;
            var tale_id = -1;
            tale_name = Str.Intern(tale_name);
            for (int i = 0; tale_id < 0 && i < tale_names.count; ++i)
                if (tale_names[i] == tale_name)
                {
                    tale_id = i;
                    for (int j = 0; !ret && j < active_states.count; ++j)
                        ret = GetTaleId(active_states[j]) == tale_id;
                }
            return ret;
        }

        public bool IsTaleActive(string tale_name)
        {
            var ret = false;
            var tale_id = -1;
            tale_name = Str.Intern(tale_name);
            for (int i = 0; tale_id < 0 && i < tale_names.count; ++i)
                if (tale_names[i] == tale_name)
                {
                    tale_id = i;
                    for (int j = 0; !ret && j < active_states.count; ++j)
                    {
                        ret = GetTaleId(active_states[j]) == tale_id;
                        ret = ret && state_names[active_states[j]] != "Awake";
                    }
                }
            return ret;
        }

        public double EnterTimeIfActive(string tale_name, string state_name)
        {
            var ret = 0.0;
            int tale_id, state_id;
            if (IsTaleStateActive(tale_name, state_name, out tale_id, out state_id))
                ret = activation_time[state_id];
            return ret;
        }

        public double LastEnterTime(string tale_name, string state_name)
        {
            var ret = 0.0;
            if (GetTaleAndStateId(tale_name, state_name, out int tale_id, out int state_id))
                ret = activation_time[state_id];
            return ret;
        }
    }
}
